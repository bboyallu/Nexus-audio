package com.degonmusic.nexus

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.hilt.navigation.compose.hiltViewModel
import com.nexus.audio.core.playback.PlaybackController
import com.nexus.audio.core.playback.PlayerUiState
import com.nexus.audio.core.theming.builtin.BuiltInThemes
import com.nexus.audio.core.theming.runtime.LocalNexusTheme
import com.nexus.audio.core.theming.runtime.NexusTheme
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

/**
 * Minimal end-to-end wiring: applies a theme from core:theming and connects to the
 * playback service from core:playback. Proves the modules compose together.
 */
@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            NexusTheme(spec = BuiltInThemes.DJ_DEGON) {
                HomeScreen()
            }
        }
    }
}

@dagger.hilt.android.lifecycle.HiltViewModel
class PlayerViewModel @Inject constructor(
    controller: PlaybackController,
) : ViewModel() {
    val state = controller.state
    init { controller.connect() }
}

@Composable
fun HomeScreen(vm: PlayerViewModel = hiltViewModel()) {
    val theme = LocalNexusTheme.current
    val state: PlayerUiState by vm.state.collectAsStateWithLifecycle()
    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(Modifier.padding(24.dp)) {
            Text("Nexus Audio", style = MaterialTheme.typography.headlineMedium)
            Text("Theme: ${theme.spec.name}", style = MaterialTheme.typography.bodyMedium)
            Text(
                if (state.connected) "Player service connected" else "Connecting to player…",
                style = MaterialTheme.typography.bodySmall,
            )
        }
    }
}
