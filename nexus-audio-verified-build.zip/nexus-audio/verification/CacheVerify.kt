// Verbatim LRU+TTL logic from InMemorySearchCache (Mutex/coroutines dropped so it
// runs synchronously; the map behaviour under test is unchanged).
data class SearchPage(val tag: String)
class Cache(val maxEntries: Int, val ttl: Long, val now: () -> Long) {
    data class CacheEntry(val page: SearchPage, val expiresAt: Long)
    val map = object : LinkedHashMap<String, CacheEntry>(16, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, CacheEntry>) = size > maxEntries
    }
    fun get(key: String): SearchPage? {
        val e = map[key] ?: return null
        return if (e.expiresAt <= now()) { map.remove(key); null } else e.page
    }
    fun put(key: String, page: SearchPage) { map[key] = CacheEntry(page, now() + ttl) }
}
fun main() {
    // 1) TTL expiry
    var t = 0L
    val c = Cache(maxEntries = 100, ttl = 1000, now = { t })
    c.put("a", SearchPage("A"))
    t = 500;  check(c.get("a") != null)        { "should be live at 500ms" }
    t = 2000; check(c.get("a") == null)        { "should be expired at 2000ms" }

    // 2) Size-bounded LRU eviction (access reorders recency)
    var t2 = 0L
    val lru = Cache(maxEntries = 2, ttl = 100000, now = { t2 })
    lru.put("A", SearchPage("A"))
    lru.put("B", SearchPage("B"))
    check(lru.get("A") != null)                // touch A -> A is now most-recent
    lru.put("C", SearchPage("C"))              // evicts least-recent = B
    check(lru.get("B") == null)  { "B should have been evicted" }
    check(lru.get("A") != null)  { "A should survive (was touched)" }
    check(lru.get("C") != null)  { "C should be present" }
    println("InMemorySearchCache logic: ALL CHECKS PASSED")
}
