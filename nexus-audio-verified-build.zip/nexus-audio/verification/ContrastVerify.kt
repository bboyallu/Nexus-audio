import kotlin.math.pow
// Minimal stand-in for Compose Color (same 0..1 float channels + lerp), so the
// REAL Contrast algorithm below can run without the Compose dependency.
data class Color(val red: Float, val green: Float, val blue: Float) {
    companion object { val White = Color(1f,1f,1f); val Black = Color(0f,0f,0f) }
}
fun lerp(a: Color, b: Color, t: Float) =
    Color(a.red+(b.red-a.red)*t, a.green+(b.green-a.green)*t, a.blue+(b.blue-a.blue)*t)

// ---- verbatim algorithm from Contrast.kt ----
fun lin(c: Float): Double = if (c <= 0.03928f) c/12.92 else ((c+0.055)/1.055).toDouble().pow(2.4)
fun luminance(c: Color): Double = 0.2126*lin(c.red)+0.7152*lin(c.green)+0.0722*lin(c.blue)
fun ratio(a: Color, b: Color): Double { val la=luminance(a)+0.05; val lb=luminance(b)+0.05; return if (la>lb) la/lb else lb/la }
fun ensure(fg: Color, bg: Color, target: Double = 4.5): Color {
    if (ratio(fg,bg) >= target) return fg
    val anchor = if (luminance(bg) < 0.5) Color.White else Color.Black
    var lo=0f; var hi=1f; var best=anchor
    var i=0
    while (i<12) { val t=(lo+hi)/2f; val c=lerp(fg,anchor,t); if (ratio(c,bg)>=target){best=c;hi=t} else {lo=t}; i++ }
    return best
}
fun c(argb: Int) = Color(((argb shr 16) and 0xFF)/255f, ((argb shr 8) and 0xFF)/255f, (argb and 0xFF)/255f)
fun main() {
    check(ratio(Color.Black, Color.White) > 20.0) { "max contrast wrong" }
    val bg = c(0x050505)            // near-black OLED background
    val fixed = ensure(c(0x1A1A1A), bg, 4.5) // unreadable dim grey -> must be lifted
    check(ratio(fixed, bg) >= 4.5) { "ensure() failed to reach AA: ${ratio(fixed,bg)}" }
    check(ratio(c(0x1A1A1A), bg) < 4.5)       // confirm the input really was failing
    println("Contrast.kt logic: ALL CHECKS PASSED (lifted ratio=%.2f)".format(ratio(fixed,bg)))
}
