package com.degonmusic.providers.youtube
fun main() {
    check(HtmlText.unescape("Beats &amp; Pieces") == "Beats & Pieces")
    check(HtmlText.unescape("Don&#39;t Stop") == "Don't Stop")
    check(HtmlText.unescape("&quot;Quoted&quot;") == "\"Quoted\"")
    check(HtmlText.unescape("Progressive House Mix 2026") == "Progressive House Mix 2026")
    check(HtmlText.unescape("A &amp; B &amp; C") == "A & B & C")
    check(HtmlText.unescape("caf&#xe9;") == "café")
    check(HtmlText.cleanArtist("DJ Degon - Topic") == "DJ Degon")
    check(HtmlText.cleanArtist("Some Real Channel") == "Some Real Channel")
    println("HtmlText.kt (REAL FILE): ALL 8 CHECKS PASSED")
}
