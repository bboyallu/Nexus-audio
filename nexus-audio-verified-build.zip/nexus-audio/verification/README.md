# Build & Verification Status

## What was actually verified (in a sandbox, for real)

The framework-independent logic was compiled and **run** with a real Kotlin
compiler + JDK 21. Assertions execute and pass — see `verification/RESULTS.txt`.

| Component | Status | How |
|---|---|---|
| `HtmlText` (the real source file) | ✅ compiles + 8/8 runtime checks pass | kotlinc + assertion runner |
| `Contrast` algorithm (luminance / ratio / AA clamp) | ✅ runtime checks pass | embedded in harness |
| `InMemorySearchCache` (TTL + LRU eviction) | ✅ runtime checks pass | embedded in harness |

Reproduce locally with nothing but a JDK + kotlinc:
```bash
cd verification
kotlinc HtmlText.kt HtmlRunner.kt -include-runtime -d html.jar && java -jar html.jar
kotlinc ContrastVerify.kt -include-runtime -d c.jar && java -jar c.jar
kotlinc CacheVerify.kt    -include-runtime -d k.jar && java -jar k.jar
```

### A real bug this caught
Compiling the cache exposed a name collision: the nested `Entry` class shadowed
`LinkedHashMap.Entry`. **Fixed** in `source/youtube/.../SearchCache.kt` (renamed to
`CacheEntry`). This is exactly why you compile instead of eyeballing.

## What could NOT be built here, and why

A full Android/Gradle build was **impossible in the sandbox** — the environment can
only reach a fixed allow-list (PyPI, npm, crates, GitHub, Ubuntu apt). It cannot
reach:
- `dl.google.com` / `maven.google.com` (Android Gradle Plugin, Compose, Media3)
- `repo1.maven.org` (Maven Central — Ktor, Hilt, kotlinx)
- `services.gradle.org` (Gradle itself)
- the Android SDK

So AGP, the Compose/Media3/Ktor/Hilt artifacts, and the SDK can't be downloaded,
and a modern kotlinc (2.0) isn't reachable either (release assets host is blocked).
The only offline Kotlin was Ubuntu's 1.3.31 — fine for pure-stdlib logic, too old
for the modern syntax (`data object`, trailing commas) used elsewhere.

## Get a verified FULL build on your machine (one pass)

Prerequisites: **JDK 17**, **Android SDK** (set `ANDROID_HOME` / `local.properties`),
internet access.

```bash
# 1) generate the wrapper jar (needs a local Gradle once; or use your IDE's)
gradle wrapper --gradle-version 8.9

# 2) compile every library module
./gradlew :core:theming:compileReleaseKotlin \
          :core:playback:compileReleaseKotlin \
          :source:youtube:compileReleaseKotlin

# 3) run the unit tests (HtmlText + the 12-case MockEngine provider suite)
./gradlew :source:youtube:testDebugUnitTest

# 4) assemble the app APK that wires all three modules together
./gradlew :app:assembleDebug
```

`local.properties` should contain:
```
sdk.dir=/path/to/Android/sdk
```

## Honest expectation for the first full build

The logic is verified; the framework wiring is written carefully but **not** compiled
here. Budget for a few first-build fixes — most likely candidates: a Compose-compiler
/ Kotlin version pin, a Hilt KSP setup detail, or a Media3 artifact split. The module
structure, contracts, and the verified logic won't change; these would be config
nits, not redesigns.
