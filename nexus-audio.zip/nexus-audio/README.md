# Nexus Audio

Monorepo for the personal music ecosystem. This bundle contains the foundational
modules built so far, the architecture blueprint, and root Gradle wiring.

```
nexus-audio/
├── settings.gradle.kts          # includes the three modules
├── build.gradle.kts             # plugin versions
├── gradle/libs.versions.toml    # version catalog (single source of truth)
├── docs/
│   └── architecture.md          # the full system blueprint + reasoning
├── core/
│   ├── theming/                 # appearance engine (ThemeSpec, resolver, contrast, DataStore)
│   └── playback/                # Media3 engine (session service, controller, effects)
└── source/
    └── youtube/                 # YouTube SEARCH provider (+ launcher, + MockEngine tests)
```

## What each module is

- **core:theming** — the entire app appearance as one serializable `ThemeSpec`.
  Token resolver, automatic WCAG contrast clamping, perf-tier effect degradation,
  built-in themes (incl. DJ Degon Mode), import/export, DataStore persistence.
- **core:playback** — Media3/ExoPlayer in a foreground `MediaSessionService`, with
  a UI-facing `PlaybackController` (StateFlow), lazy stream resolution for expiring
  server URLs, audio effects (EQ/bass/loudness), queue, and sleep timer. Plays local
  files out of the box.
- **source:youtube** — YouTube as a **search/metadata** provider implementing the
  `MusicProvider` contract (NOT playback — there's no licensed audio path). Typed
  `ProviderError`s, pagination, mandatory caching, HTML-cleaned titles, an external
  app launcher, and a 12-case MockEngine test suite.

## Build state — read this

This is a **structural assembly**, not a verified build. It was authored outside an
Android/Gradle environment, so nothing here has been run through `./gradlew`.

- Module `build.gradle.kts` files currently **inline** their versions for standalone
  readability. The catalog in `gradle/libs.versions.toml` mirrors those exact values;
  migrate `implementation("...:x.y.z")` → `implementation(libs.foo)` when convenient.
- You'll need the Gradle wrapper (`gradle wrapper`) and an `app` module to assemble
  a runnable APK; these modules are libraries.
- Two deliberate stubs remain: **crossfade** (playback) and the **production color
  harmonizer** (theming — swap `SchemeBuilder` for MaterialKolor). Both are documented
  in their module READMEs.

## Suggested next modules (see docs/architecture.md)

1. `core:model` + `core:media-source` — extract the shared contract that
   `source:youtube` currently vendors in `contract/Contract.kt`.
2. `source:subsonic` — the first **streaming** provider (real `STREAM_AUDIO`),
   covering Navidrome/Subsonic. This is what makes the playback module play servers.
3. `feature:nowplaying` — wire `core:playback` + `core:theming` into a screen.
