# core:playback

The audio engine: Media3 / ExoPlayer wrapped in a foreground `MediaSessionService`,
with a single UI-facing `PlaybackController` exposing playback as a `StateFlow`.

## What works out of the box

- Plays **local files** immediately (the default `LocalPlaybackResolver` treats a
  MediaStore `content://` uri as the mediaId).
- **Lazy stream resolution** — every track resolves its real URL only as ExoPlayer
  opens it, so expiring Subsonic/Jellyfin/YT links never go stale mid-queue.
- One unified path for `content://`, `https://`, and **HLS** (set `mimeHint`).
- Gapless (ExoPlayer default), audio focus, becoming-noisy handling, wake lock.
- Queue, repeat/shuffle, seek, speed, **EQ + bass boost + loudness/ReplayGain hook**,
  **sleep timer**.
- System/notification/Bluetooth controls via the media session.

## Formats

ExoPlayer covers MP3, AAC, FLAC, WAV, Ogg/Opus out of the box. **ALAC** needs the
`media3-decoder` FFmpeg/extension or a custom renderer — wire that in the app module
if you need it.

## Wire it

```kotlin
// 1) Connect once, observe everywhere
@HiltViewModel
class PlayerViewModel @Inject constructor(
    private val controller: PlaybackController,
) : ViewModel() {
    init { controller.connect() }
    val state = controller.state
    fun play(items: List<PlayableItem>, index: Int) = controller.setQueue(items, index)
    fun toggle() = controller.togglePlayPause()
}

// 2) Map your domain Track -> PlayableItem at the call site
fun Track.toPlayable() = PlayableItem(
    mediaId = id.toString(),      // your GlobalId; round-trips to the resolver
    title = title, artist = artist, album = album,
    artworkUri = artworkUri, durationMs = durationMs,
)
```

## Connect to your servers

Replace the DI binding in `PlaybackModule` with a resolver that delegates to your
`ProviderRegistry`:

```kotlin
class ProviderPlaybackResolver @Inject constructor(
    private val registry: ProviderRegistry,
) : PlaybackResolver {
    override suspend fun resolve(mediaId: String): PlaybackRequest {
        val gid = GlobalId.parse(mediaId)
        val src = registry.get(gid.provider).resolvePlayback(gid.track).getOrThrow()
        return when (src) {
            is PlaybackSource.LocalFile      -> PlaybackRequest(mediaId, src.uri)
            is PlaybackSource.ProgressiveHttp-> PlaybackRequest(mediaId, src.url, src.headers)
            is PlaybackSource.Hls            -> PlaybackRequest(mediaId, src.url, src.headers)
            is PlaybackSource.ExternalControl-> error("control-only provider")
        }
    }
}
```

## Honest limitations / TODO

- **Crossfade is not implemented.** Gapless is automatic; true crossfade needs a
  custom `AudioProcessor` or a dual-player setup. Left as a deliberate stub rather
  than faked — it's the one genuinely hard part of the audio pipeline.
- **Android Auto** is one step away: change `MusicService` to extend
  `MediaLibraryService` and supply a `MediaLibrarySession.Callback` browse tree.
- **ReplayGain** tag reading happens in your metadata pipeline; this module only
  exposes `AudioEffectsController.applyTrackGainDb`.
- Audio effects use `android.media.audiofx`, which is global to an audio session —
  fine for one player, but don't instantiate twice against the same session id.

## Not verified to compile here

Authored outside an Android/Gradle environment. Media3 version in `build.gradle.kts`
is a placeholder to reconcile with your catalog; treat the first `./gradlew` as the
integration step.
