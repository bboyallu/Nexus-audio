package com.nexus.audio.core.playback

import javax.inject.Inject

/**
 * Zero-config resolver: treats the mediaId as a directly-playable URI
 * (e.g. a MediaStore content:// uri). Lets the module play local files with no
 * provider wired. Replace via DI with one delegating to your ProviderRegistry.
 */
class LocalPlaybackResolver @Inject constructor() : PlaybackResolver {
    override suspend fun resolve(mediaId: String): PlaybackRequest =
        PlaybackRequest(mediaId = mediaId, uri = mediaId)
}
