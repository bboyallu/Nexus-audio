package com.nexus.audio.core.playback

import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata

/**
 * Maps a [PlayableItem] to a Media3 [MediaItem]. The URI is a sentinel
 * `nexus:<mediaId>` — the real stream is resolved later by [PlaybackResolver].
 * The mediaId round-trips via [MediaItem.mediaId] and the sentinel URI.
 */
internal fun PlayableItem.toMediaItem(): MediaItem {
    val metadata = MediaMetadata.Builder()
        .setTitle(title)
        .setArtist(artist)
        .setAlbumTitle(album)
        .setArtworkUri(artworkUri?.let(Uri::parse))
        .setIsPlayable(true)
        .build()

    return MediaItem.Builder()
        .setMediaId(mediaId)
        .setUri("nexus:$mediaId")
        .apply { mimeHint?.let { setMimeType(it) } }
        .setMediaMetadata(metadata)
        .build()
}
