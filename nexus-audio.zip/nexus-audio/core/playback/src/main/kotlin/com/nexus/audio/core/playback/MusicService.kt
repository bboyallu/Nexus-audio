package com.nexus.audio.core.playback

import android.content.Intent
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.nexus.audio.core.playback.audio.AudioEffectsController
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

/**
 * Hosts the player and exposes a [MediaSession] so the system, notification,
 * Bluetooth, and (when upgraded to MediaLibraryService) Android Auto all control
 * the same playback. Runs as a foreground media service.
 *
 * Android Auto upgrade path: change the superclass to MediaLibraryService and
 * supply a MediaLibrarySession.Callback that serves your browse tree.
 */
@AndroidEntryPoint
class MusicService : MediaSessionService() {

    @Inject lateinit var playerFactory: PlayerFactory

    private var mediaSession: MediaSession? = null
    private var effects: AudioEffectsController? = null

    override fun onCreate() {
        super.onCreate()
        val player: ExoPlayer = playerFactory.create()
        effects = AudioEffectsController(player)
        mediaSession = MediaSession.Builder(this, player).build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? =
        mediaSession

    /** Stop when the user swipes the app away and nothing is playing. */
    override fun onTaskRemoved(rootIntent: Intent?) {
        val player = mediaSession?.player ?: return
        if (!player.playWhenReady || player.mediaItemCount == 0) {
            stopSelf()
        }
    }

    override fun onDestroy() {
        effects?.release()
        mediaSession?.run {
            player.release()
            release()
        }
        effects = null
        mediaSession = null
        super.onDestroy()
    }
}
