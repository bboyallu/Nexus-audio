package com.nexus.audio.core.playback

import android.content.ComponentName
import android.content.Context
import androidx.core.content.ContextCompat
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import javax.inject.Inject
import javax.inject.Singleton

/**
 * The only class the UI talks to. Connects to [MusicService], exposes a single
 * [state] StateFlow, and forwards commands. Survives across screens as a singleton;
 * call [connect] from your root and [release] when the app process is done.
 */
@Singleton
class PlaybackController @Inject constructor(
    @ApplicationContext private val context: Context,
) {
    private val scope = CoroutineScope(Dispatchers.Main.immediate + SupervisorJob())
    private var controller: MediaController? = null
    private var ticker: kotlinx.coroutines.Job? = null

    private val _state = MutableStateFlow(PlayerUiState())
    val state: StateFlow<PlayerUiState> = _state.asStateFlow()

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) = pushState()
    }

    fun connect() {
        if (controller != null) return
        val token = SessionToken(context, ComponentName(context, MusicService::class.java))
        val future = MediaController.Builder(context, token).buildAsync()
        future.addListener({
            controller = future.get().also {
                it.addListener(listener)
                pushState()
                startTicker()
            }
        }, ContextCompat.getMainExecutor(context))
    }

    // --- commands ---------------------------------------------------------

    fun setQueue(items: List<PlayableItem>, startIndex: Int = 0, playWhenReady: Boolean = true) {
        val c = controller ?: return
        c.setMediaItems(items.map { it.toMediaItem() }, startIndex, C.TIME_UNSET)
        c.prepare()
        c.playWhenReady = playWhenReady
    }

    fun addToQueue(item: PlayableItem) { controller?.addMediaItem(item.toMediaItem()) }
    fun removeAt(index: Int) { controller?.removeMediaItem(index) }
    fun clearQueue() { controller?.clearMediaItems() }

    fun togglePlayPause() {
        val c = controller ?: return
        if (c.isPlaying) c.pause() else c.play()
    }

    fun pause() { controller?.pause() }
    fun play() { controller?.play() }

    fun next() { controller?.seekToNextMediaItem() }
    fun previous() { controller?.seekToPreviousMediaItem() }
    fun seekTo(positionMs: Long) { controller?.seekTo(positionMs) }
    fun playIndex(index: Int) { controller?.seekToDefaultPosition(index) }

    fun setRepeatMode(mode: RepeatMode) {
        controller?.repeatMode = when (mode) {
            RepeatMode.OFF -> Player.REPEAT_MODE_OFF
            RepeatMode.ONE -> Player.REPEAT_MODE_ONE
            RepeatMode.ALL -> Player.REPEAT_MODE_ALL
        }
    }

    fun toggleShuffle() {
        val c = controller ?: return
        c.shuffleModeEnabled = !c.shuffleModeEnabled
    }

    fun setSpeed(speed: Float) { controller?.setPlaybackSpeed(speed.coerceIn(0.25f, 3f)) }

    fun release() {
        ticker?.cancel()
        ticker = null
        controller?.removeListener(listener)
        controller?.release()
        controller = null
    }

    // --- internals --------------------------------------------------------

    private fun startTicker() {
        ticker?.cancel()
        ticker = scope.launch {
            while (isActive) {
                if (controller?.isPlaying == true) pushState()
                delay(500)
            }
        }
    }

    private fun pushState() {
        val c = controller
        if (c == null) {
            _state.value = PlayerUiState(connected = false)
            return
        }
        val md = c.currentMediaItem?.mediaMetadata
        _state.value = PlayerUiState(
            connected = true,
            isPlaying = c.isPlaying,
            isBuffering = c.playbackState == Player.STATE_BUFFERING,
            mediaId = c.currentMediaItem?.mediaId,
            title = md?.title?.toString(),
            artist = md?.artist?.toString(),
            album = md?.albumTitle?.toString(),
            artworkUri = md?.artworkUri?.toString(),
            durationMs = c.duration.takeIf { it != C.TIME_UNSET }?.coerceAtLeast(0) ?: 0,
            positionMs = c.currentPosition.coerceAtLeast(0),
            bufferedPositionMs = c.bufferedPosition.coerceAtLeast(0),
            hasNext = c.hasNextMediaItem(),
            hasPrevious = c.hasPreviousMediaItem(),
            repeatMode = when (c.repeatMode) {
                Player.REPEAT_MODE_ONE -> RepeatMode.ONE
                Player.REPEAT_MODE_ALL -> RepeatMode.ALL
                else -> RepeatMode.OFF
            },
            shuffle = c.shuffleModeEnabled,
            speed = c.playbackParameters.speed,
            queueSize = c.mediaItemCount,
        )
    }
}
