package com.nexus.audio.core.playback

/**
 * The seam between the player and your providers. The player never knows about
 * Subsonic/Jellyfin/local — it just asks the resolver to turn a stable mediaId
 * into a concrete, currently-valid stream at the moment playback starts.
 *
 * This lazy resolution is deliberate: streaming URLs from Subsonic/Jellyfin/YT
 * expire, so resolving a 2-hour queue up front would break. We resolve each
 * track only as ExoPlayer opens it.
 */
interface PlaybackResolver {
    /** @param mediaId the stable id you put on the [PlayableItem] (e.g. a GlobalId string). */
    suspend fun resolve(mediaId: String): PlaybackRequest
}

data class PlaybackRequest(
    val mediaId: String,
    /** Concrete content://, file:// or https:// URI to stream from. */
    val uri: String,
    /** Auth/range headers for remote sources; ignored for local URIs. */
    val headers: Map<String, String> = emptyMap(),
)

/**
 * What the UI hands the player. Map your domain `Track` to this at the call site.
 * [mediaId] is opaque to the player and round-trips back to [PlaybackResolver].
 */
data class PlayableItem(
    val mediaId: String,
    val title: String,
    val artist: String,
    val album: String? = null,
    val artworkUri: String? = null,
    val durationMs: Long? = null,
    /** Set to MimeTypes.APPLICATION_M3U8 for HLS so the right source is built. */
    val mimeHint: String? = null,
)
