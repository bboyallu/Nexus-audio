package com.nexus.audio.core.playback

import android.content.Context
import android.net.Uri
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.ResolvingDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.runBlocking
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Builds the single ExoPlayer instance. The key piece is the [ResolvingDataSource]:
 * every MediaItem carries a sentinel `nexus:<mediaId>` URI, and the real stream URL
 * is fetched from [PlaybackResolver] at open time. One unified path covers
 * content:// (local), https:// (servers) and HLS — DefaultDataSource picks the
 * right transport, DefaultMediaSourceFactory picks progressive vs HLS by mime/uri.
 */
@Singleton
class PlayerFactory @Inject constructor(
    @ApplicationContext private val context: Context,
    private val resolver: PlaybackResolver,
) {
    fun create(): ExoPlayer {
        val httpFactory = DefaultHttpDataSource.Factory()
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15_000)
            .setReadTimeoutMs(15_000)

        val upstream = DefaultDataSource.Factory(context, httpFactory)

        // Resolver runs on ExoPlayer's loading thread (off the main thread), so
        // blocking here is acceptable.
        val resolving = ResolvingDataSource.Factory(upstream) { dataSpec ->
            val mediaId = dataSpec.uri.schemeSpecificPart
            val request = runBlocking { resolver.resolve(mediaId) }
            dataSpec.buildUpon()
                .setUri(Uri.parse(request.uri))
                .setHttpRequestHeaders(request.headers)
                .build()
        }

        val sourceFactory = DefaultMediaSourceFactory(resolving)

        val audioAttributes = AudioAttributes.Builder()
            .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
            .setUsage(C.USAGE_MEDIA)
            .build()

        return ExoPlayer.Builder(context)
            .setMediaSourceFactory(sourceFactory)
            .setAudioAttributes(audioAttributes, /* handleAudioFocus = */ true)
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_NETWORK)
            .build()
    }
}
