package com.nexus.audio.core.playback

/** Immutable snapshot the UI observes. Position/buffered tick while playing. */
data class PlayerUiState(
    val connected: Boolean = false,
    val isPlaying: Boolean = false,
    val isBuffering: Boolean = false,
    val mediaId: String? = null,
    val title: String? = null,
    val artist: String? = null,
    val album: String? = null,
    val artworkUri: String? = null,
    val durationMs: Long = 0,
    val positionMs: Long = 0,
    val bufferedPositionMs: Long = 0,
    val hasNext: Boolean = false,
    val hasPrevious: Boolean = false,
    val repeatMode: RepeatMode = RepeatMode.OFF,
    val shuffle: Boolean = false,
    val speed: Float = 1f,
    val queueSize: Int = 0,
)

enum class RepeatMode { OFF, ONE, ALL }
