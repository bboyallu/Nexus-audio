package com.nexus.audio.core.playback.audio

import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer

/**
 * Binds platform audio effects to the player's audio session. Rebinds whenever
 * the session id changes (it changes when ExoPlayer reinitialises its output).
 *
 * ReplayGain note: Android has no native ReplayGain. Read the track's gain tag
 * during indexing, then call [applyTrackGainDb] on each track change to feed it
 * into the LoudnessEnhancer. This module exposes the hook; tag reading lives in
 * your metadata pipeline.
 */
class AudioEffectsController(private val player: ExoPlayer) {

    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var loudness: LoudnessEnhancer? = null
    private var sessionId: Int = player.audioSessionId

    private val listener = object : Player.Listener {
        override fun onAudioSessionIdChanged(audioSessionId: Int) {
            sessionId = audioSessionId
            rebind()
        }
    }

    init {
        player.addListener(listener)
        rebind()
    }

    /** Number of EQ bands the device exposes (typically 5). */
    val bandCount: Int get() = equalizer?.numberOfBands?.toInt() ?: 0

    /** Inclusive [min, max] gain in millibels for EQ bands. */
    val bandLevelRange: IntRange
        get() = equalizer?.bandLevelRange?.let { it[0].toInt()..it[1].toInt() } ?: 0..0

    fun centerFrequencyHz(band: Int): Int = equalizer?.getCenterFreq(band.toShort())?.div(1000) ?: 0

    fun setEqEnabled(enabled: Boolean) { equalizer?.enabled = enabled }

    fun setBandLevel(band: Int, millibels: Int) {
        equalizer?.setBandLevel(band.toShort(), millibels.toShort())
    }

    /** 0..1000 strength. */
    fun setBassBoost(strength: Int) {
        bassBoost?.apply {
            enabled = strength > 0
            if (strengthSupported) setStrength(strength.coerceIn(0, 1000).toShort())
        }
    }

    /** Per-track gain (e.g. from ReplayGain) applied as a loudness target. */
    fun applyTrackGainDb(db: Float) {
        loudness?.apply {
            enabled = true
            setTargetGain((db * 100).toInt()) // mB
        }
    }

    private fun rebind() {
        release(keepListener = true)
        runCatching {
            equalizer = Equalizer(0, sessionId)
            bassBoost = BassBoost(0, sessionId)
            loudness = LoudnessEnhancer(sessionId)
        }
    }

    fun release(keepListener: Boolean = false) {
        equalizer?.release(); equalizer = null
        bassBoost?.release(); bassBoost = null
        loudness?.release(); loudness = null
        if (!keepListener) player.removeListener(listener)
    }
}
