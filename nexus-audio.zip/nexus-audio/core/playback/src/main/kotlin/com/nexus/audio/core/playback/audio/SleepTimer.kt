package com.nexus.audio.core.playback.audio

import com.nexus.audio.core.playback.PlaybackController
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Pauses playback after a countdown. Exposes remaining millis so the UI can show
 * a live countdown. "End of track" mode is a TODO hook: observe the controller's
 * position and fire when the current item is about to end.
 */
@Singleton
class SleepTimer @Inject constructor(
    private val controller: PlaybackController,
) {
    private val scope = CoroutineScope(Dispatchers.Main.immediate + SupervisorJob())
    private var job: Job? = null

    private val _remainingMs = MutableStateFlow<Long?>(null)
    val remainingMs: StateFlow<Long?> = _remainingMs.asStateFlow()

    fun start(durationMs: Long) {
        cancel()
        job = scope.launch {
            var left = durationMs
            while (left > 0) {
                _remainingMs.value = left
                delay(1_000)
                left -= 1_000
            }
            _remainingMs.value = 0
            controller.pause()
            _remainingMs.value = null
        }
    }

    fun cancel() {
        job?.cancel()
        job = null
        _remainingMs.value = null
    }
}
