package com.nexus.audio.core.playback.di

import com.nexus.audio.core.playback.LocalPlaybackResolver
import com.nexus.audio.core.playback.PlaybackResolver
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent

/**
 * Binds the out-of-the-box local resolver. In the app module, REPLACE this
 * binding with one that delegates to your ProviderRegistry so remote sources
 * (Subsonic/Jellyfin/...) resolve through their providers.
 */
@Module
@InstallIn(SingletonComponent::class)
abstract class PlaybackModule {

    @Binds
    abstract fun bindResolver(impl: LocalPlaybackResolver): PlaybackResolver
}
