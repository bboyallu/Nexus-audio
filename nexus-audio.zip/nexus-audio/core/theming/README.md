# core:theming

The full appearance engine for Nexus Audio. One serializable `ThemeSpec` is the
single source of truth; rendering, persistence, export/import, sharing and live
preview are all just that object in different contexts.

## Drop in

1. Copy this module into your project and add `include(":core:theming")` to `settings.gradle.kts`.
2. Add the plugins/deps in `build.gradle.kts` to your version catalog (versions there are illustrative).
3. Wire the root once.

## Wire the root

```kotlin
@HiltViewModel
class AppViewModel @Inject constructor(repo: ThemeRepository) : ViewModel() {
    val theme = repo.activeTheme.stateIn(
        viewModelScope, SharingStarted.Eagerly, BuiltInThemes.DEFAULT
    )
}

@Composable
fun NexusApp(vm: AppViewModel = hiltViewModel()) {
    val spec by vm.theme.collectAsStateWithLifecycle()
    val perfTier = rememberPerfTier()                 // map battery/power-save -> PerfTier
    val albumSeed by rememberCurrentTrackAlbumSeed()  // your palette extractor, nullable

    NexusTheme(spec = spec, albumArtSeed = albumSeed, perfTier = perfTier) {
        // ... your navigation host. Read extras via LocalNexusTheme.current.effects
    }
}
```

## Live preview & per-screen overrides

Both are the same primitive — nest `NexusTheme` with a different spec:

```kotlin
NexusTheme(spec = draftSpec) { ThemeEditorPreview() }     // live preview
NexusTheme(spec = spec.copy(mode = Mode.OLED)) { NowPlaying() } // per-screen
```

## What's enforced for you

- **Contrast** — `ThemeResolver` auto-clamps every on-color (WCAG AA). Arbitrary
  user accents never produce unreadable text. The editor shows live badges via
  `ContrastCheck.evaluate`.
- **Performance** — `EffectSpec.degradeTo(tier)` strips blur/animation under
  `BATTERY`. Visualizers should read a fixed FFT buffer off the audio thread and
  honour `ResolvedEffects.reactiveFps`.
- **Untrusted themes** — `ThemePortability.import` validates schema version and
  clamps blur/font/animation, drops non-https background URIs, re-runs migration.

## The one production swap

`SchemeBuilder.build()` is a dependency-free HSL approximation. For true Material
tonal harmony, replace its body with MaterialKolor / material-color-utilities
`dynamicColorScheme(seed)`. Nothing else changes — the resolver, contrast clamp
and all screens consume the resulting `ColorScheme` identically.

## Not verified to compile here

This was authored outside an Android/Gradle environment, so it has not been run
through a build. Versions in `build.gradle.kts` are placeholders to reconcile with
your catalog. Logic and types are internally consistent; treat the first `./gradlew`
as the integration step.
