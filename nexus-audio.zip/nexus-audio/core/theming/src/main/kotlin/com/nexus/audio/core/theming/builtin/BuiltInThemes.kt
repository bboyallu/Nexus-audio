package com.nexus.audio.core.theming.builtin

import com.nexus.audio.core.theming.model.ColorSource
import com.nexus.audio.core.theming.model.EffectSpec
import com.nexus.audio.core.theming.model.GradientStyle
import com.nexus.audio.core.theming.model.Mode
import com.nexus.audio.core.theming.model.ShapeSpec
import com.nexus.audio.core.theming.model.SurfaceSpec
import com.nexus.audio.core.theming.model.ThemeSpec

/** Ships-with-the-app themes. Users clone any of these as the base for a custom one. */
object BuiltInThemes {

    val NEON_NIGHT = ThemeSpec(
        id = "neon-night", name = "Neon Night", author = "Nexus",
        mode = Mode.DARK,
        colorSource = ColorSource.Manual(0xFF7C4DFF),
        surfaces = SurfaceSpec(backgroundArgb = 0xFF0B0B14, glowArgb = 0xFF7C4DFF, glowAlpha = 0.16f),
        effects = EffectSpec(blurDp = 18f, gradientStyle = GradientStyle.RADIAL_BLOOM, reactiveFps = 30),
    )

    val DREAMWAVE = ThemeSpec(
        id = "dreamwave", name = "DreamWave", author = "Nexus",
        mode = Mode.DARK,
        colorSource = ColorSource.Manual(0xFFFF5FA2),
        surfaces = SurfaceSpec(backgroundArgb = 0xFF120A1F, glowArgb = 0xFF36E0FF, glowAlpha = 0.18f),
        effects = EffectSpec(blurDp = 22f, gradientStyle = GradientStyle.MESH, reactiveFps = 30),
    )

    val CYBER_STUDIO = ThemeSpec(
        id = "cyber-studio", name = "Cyber Studio", author = "Nexus",
        mode = Mode.DARK,
        colorSource = ColorSource.Manual(0xFF00E5A8),
        surfaces = SurfaceSpec(backgroundArgb = 0xFF071013, glowArgb = 0xFF00E5A8, glowAlpha = 0.14f),
        effects = EffectSpec(blurDp = 14f, gradientStyle = GradientStyle.LINEAR, reactiveFps = 30),
    )

    val AURORA_PULSE = ThemeSpec(
        id = "aurora-pulse", name = "Aurora Pulse", author = "Nexus",
        mode = Mode.DARK,
        colorSource = ColorSource.Manual(0xFF53F0C4),
        surfaces = SurfaceSpec(backgroundArgb = 0xFF06121A, glowArgb = 0xFF8A7CFF, glowAlpha = 0.20f),
        effects = EffectSpec(blurDp = 24f, gradientStyle = GradientStyle.MESH, gradientAnimated = true, reactiveFps = 30),
    )

    val MINIMAL_BLACK = ThemeSpec(
        id = "minimal-black", name = "Minimal Black", author = "Nexus",
        mode = Mode.OLED,
        colorSource = ColorSource.Manual(0xFFE0E0E0),
        surfaces = SurfaceSpec(backgroundArgb = 0xFF000000),
        effects = EffectSpec(blurDp = 0f, gradientStyle = GradientStyle.NONE, gradientAnimated = false, reactiveFps = 0),
        shape = ShapeSpec(albumArtCorner = 6f, panelCorner = 10f),
    )

    val RACCOONIE_PARTY = ThemeSpec(
        id = "raccoonie-party", name = "Raccoonie Party Mode", author = "Nexus",
        mode = Mode.DARK,
        colorSource = ColorSource.AlbumArt(fallbackArgb = 0xFFFFB300), // dances with the cover art
        surfaces = SurfaceSpec(backgroundArgb = 0xFF15100A, glowArgb = 0xFFFF3D6E, glowAlpha = 0.22f),
        effects = EffectSpec(blurDp = 20f, gradientStyle = GradientStyle.MESH, reactiveFps = 60),
    )

    /** Degon's signature: near-black OLED with a cyan arc-reactor bloom. */
    val DJ_DEGON = ThemeSpec(
        id = "dj-degon", name = "DJ Degon Mode", author = "DJ Degon",
        mode = Mode.OLED,
        colorSource = ColorSource.Manual(0xFF00F3FF),
        surfaces = SurfaceSpec(backgroundArgb = 0xFF050505, glowArgb = 0xFF00F3FF, glowAlpha = 0.18f),
        effects = EffectSpec(blurDp = 20f, gradientStyle = GradientStyle.RADIAL_BLOOM, reactiveFps = 60),
        shape = ShapeSpec(albumArtCorner = 4f, panelCorner = 18f),
    )

    val ALL: List<ThemeSpec> = listOf(
        NEON_NIGHT, DREAMWAVE, CYBER_STUDIO, AURORA_PULSE,
        MINIMAL_BLACK, RACCOONIE_PARTY, DJ_DEGON,
    )

    val DEFAULT: ThemeSpec = DJ_DEGON
}
