package com.nexus.audio.core.theming.data

import androidx.datastore.core.DataStore
import com.nexus.audio.core.theming.builtin.BuiltInThemes
import com.nexus.audio.core.theming.io.ThemePortability
import com.nexus.audio.core.theming.model.ThemeSpec
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Single source of truth for appearance. The UI observes [activeTheme] at the
 * root; switching a theme is one emission and the whole tree recomposes against
 * the new tokens.
 */
@Singleton
class ThemeRepository @Inject constructor(
    private val activeStore: DataStore<ThemeSpec>,
    private val libraryStore: DataStore<ThemeLibrary>,
) {
    val activeTheme: Flow<ThemeSpec> = activeStore.data

    /** Built-ins plus the user's saved custom themes, as one list. */
    val allThemes: Flow<List<ThemeSpec>> =
        libraryStore.data.map { lib -> BuiltInThemes.ALL + lib.custom }

    suspend fun setActive(spec: ThemeSpec) {
        activeStore.updateData { spec }
    }

    suspend fun saveCustom(spec: ThemeSpec) {
        libraryStore.updateData { lib ->
            lib.copy(custom = lib.custom.filterNot { it.id == spec.id } + spec)
        }
    }

    suspend fun deleteCustom(id: String) {
        libraryStore.updateData { lib -> lib.copy(custom = lib.custom.filterNot { it.id == id }) }
    }

    /** Import a shared/marketplace theme safely (validated + clamped) and save it. */
    suspend fun importAndSave(raw: String): Result<ThemeSpec> =
        ThemePortability.import(raw).onSuccess { saveCustom(it) }

    fun export(spec: ThemeSpec): String = ThemePortability.export(spec)
}
