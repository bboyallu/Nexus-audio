package com.nexus.audio.core.theming.data

import androidx.datastore.core.Serializer
import com.nexus.audio.core.theming.builtin.BuiltInThemes
import com.nexus.audio.core.theming.model.ThemeSpec
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import java.io.InputStream
import java.io.OutputStream

/** Wrapper so user-saved custom themes persist as a single DataStore value. */
@Serializable
data class ThemeLibrary(val custom: List<ThemeSpec> = emptyList())

private val themeJson = Json { ignoreUnknownKeys = true; encodeDefaults = true }

/** JSON-backed DataStore serializer for the active theme (Proto-DataStore pattern). */
object ActiveThemeSerializer : Serializer<ThemeSpec> {
    override val defaultValue: ThemeSpec = BuiltInThemes.DEFAULT

    override suspend fun readFrom(input: InputStream): ThemeSpec =
        runCatching {
            themeJson.decodeFromString(ThemeSpec.serializer(), input.readBytes().decodeToString())
        }.getOrDefault(defaultValue)

    override suspend fun writeTo(t: ThemeSpec, output: OutputStream) {
        output.write(themeJson.encodeToString(ThemeSpec.serializer(), t).encodeToByteArray())
    }
}

object ThemeLibrarySerializer : Serializer<ThemeLibrary> {
    override val defaultValue = ThemeLibrary()

    override suspend fun readFrom(input: InputStream): ThemeLibrary =
        runCatching {
            themeJson.decodeFromString(ThemeLibrary.serializer(), input.readBytes().decodeToString())
        }.getOrDefault(defaultValue)

    override suspend fun writeTo(t: ThemeLibrary, output: OutputStream) {
        output.write(themeJson.encodeToString(ThemeLibrary.serializer(), t).encodeToByteArray())
    }
}
