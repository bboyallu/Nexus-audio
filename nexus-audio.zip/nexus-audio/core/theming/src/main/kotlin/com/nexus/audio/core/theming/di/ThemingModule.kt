package com.nexus.audio.core.theming.di

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.core.DataStoreFactory
import com.nexus.audio.core.theming.data.ActiveThemeSerializer
import com.nexus.audio.core.theming.data.ThemeLibrary
import com.nexus.audio.core.theming.data.ThemeLibrarySerializer
import com.nexus.audio.core.theming.model.ThemeSpec
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object ThemingModule {

    @Provides
    @Singleton
    fun activeThemeStore(@ApplicationContext ctx: Context): DataStore<ThemeSpec> =
        DataStoreFactory.create(serializer = ActiveThemeSerializer) {
            ctx.dataStoreFile("active_theme.json")
        }

    @Provides
    @Singleton
    fun themeLibraryStore(@ApplicationContext ctx: Context): DataStore<ThemeLibrary> =
        DataStoreFactory.create(serializer = ThemeLibrarySerializer) {
            ctx.dataStoreFile("theme_library.json")
        }
}

private fun Context.dataStoreFile(name: String): java.io.File {
    val dir = java.io.File(filesDir, "datastore").apply { mkdirs() }
    return java.io.File(dir, name)
}
