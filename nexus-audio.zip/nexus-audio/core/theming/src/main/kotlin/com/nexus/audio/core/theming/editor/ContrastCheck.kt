package com.nexus.audio.core.theming.editor

import com.nexus.audio.core.theming.model.ThemeSpec
import com.nexus.audio.core.theming.resolve.Contrast
import com.nexus.audio.core.theming.resolve.ResolveContext
import com.nexus.audio.core.theming.resolve.ThemeResolver

data class ContrastIssue(val label: String, val ratio: Double, val required: Double) {
    val passes: Boolean get() = ratio >= required
}

/**
 * Run in the theme editor to show live pass/fail badges as the user drags
 * sliders. Note: the resolver already auto-clamps on-colors, so these report
 * the POST-clamp ratios — i.e. what the user will actually see.
 */
object ContrastCheck {

    fun evaluate(spec: ThemeSpec, ctx: ResolveContext = ResolveContext()): List<ContrastIssue> {
        val c = ThemeResolver.resolve(spec, ctx).colors
        return listOf(
            ContrastIssue("Body text on background", Contrast.ratio(c.onBackground, c.background), 4.5),
            ContrastIssue("Text on surface", Contrast.ratio(c.onSurface, c.surface), 4.5),
            ContrastIssue("Label on primary", Contrast.ratio(c.onPrimary, c.primary), 4.5),
            ContrastIssue("Secondary text", Contrast.ratio(c.onSurfaceVariant, c.surfaceVariant), 3.0),
        )
    }

    fun allPass(spec: ThemeSpec): Boolean = evaluate(spec).all { it.passes }
}
