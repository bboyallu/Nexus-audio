package com.nexus.audio.core.theming.io

import com.nexus.audio.core.theming.model.CURRENT_SCHEMA
import com.nexus.audio.core.theming.model.ThemeSpec
import kotlinx.serialization.json.Json

/**
 * A theme downloaded from the marketplace or a friend is untrusted input.
 * Never render a shared spec as-is: validate the version, clamp values that
 * could break layout or kill the frame rate, and let the resolver re-enforce
 * contrast at render time.
 */
object ThemePortability {

    private val json = Json {
        prettyPrint = true
        ignoreUnknownKeys = true  // tolerate fields from newer minor versions
        encodeDefaults = true
    }

    val fileExtension = "nexustheme"

    fun export(spec: ThemeSpec): String = json.encodeToString(ThemeSpec.serializer(), spec)

    fun import(raw: String): Result<ThemeSpec> = runCatching {
        val parsed = json.decodeFromString(ThemeSpec.serializer(), raw)
        require(parsed.schemaVersion <= CURRENT_SCHEMA) {
            "Theme requires a newer app version (schema ${parsed.schemaVersion})."
        }
        sanitize(migrate(parsed))
    }

    /** Forward-migration hook. No-ops today; real steps land here as schema grows. */
    private fun migrate(spec: ThemeSpec): ThemeSpec =
        if (spec.schemaVersion == CURRENT_SCHEMA) spec
        else spec.copy(schemaVersion = CURRENT_SCHEMA)

    fun sanitize(spec: ThemeSpec): ThemeSpec = spec.copy(
        typography = spec.typography.copy(
            fontScale = spec.typography.fontScale.coerceIn(0.8f, 1.6f),
        ),
        motion = spec.motion.copy(
            animationScale = spec.motion.animationScale.coerceIn(0.5f, 2.0f),
            crossfadeMs = spec.motion.crossfadeMs.coerceIn(0, 12_000),
        ),
        effects = spec.effects.copy(
            blurDp = spec.effects.blurDp.coerceIn(0f, 40f),
            reactiveFps = spec.effects.reactiveFps.coerceIn(0, 60),
        ),
        shape = spec.shape.copy(
            albumArtCorner = spec.shape.albumArtCorner.coerceIn(0f, 200f),
            panelCorner = spec.shape.panelCorner.coerceIn(0f, 40f),
        ),
        surfaces = spec.surfaces.copy(
            // drop non-https remote backgrounds; allow only http(s)/content/file
            backgroundImageUri = spec.surfaces.backgroundImageUri?.takeIf(::isSafeUri),
            backgroundImageDim = spec.surfaces.backgroundImageDim.coerceIn(0f, 1f),
        ),
    )

    private fun isSafeUri(uri: String): Boolean =
        uri.startsWith("https://") || uri.startsWith("content://") || uri.startsWith("file://")
}
