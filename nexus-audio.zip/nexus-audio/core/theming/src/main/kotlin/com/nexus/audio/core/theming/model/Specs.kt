package com.nexus.audio.core.theming.model

import kotlinx.serialization.Serializable

@Serializable
data class SurfaceSpec(
    val backgroundArgb: Long = 0xFF0A0A0A,
    val glowArgb: Long? = null,
    val glowAlpha: Float = 0f,
    /** Optional user background image (validated on import). */
    val backgroundImageUri: String? = null,
    val backgroundImageDim: Float = 0.45f,
)

@Serializable
enum class FontFamilyToken { DEFAULT, ROUNDED, MONO, SERIF }

@Serializable
data class TypographySpec(
    /** User multiplier; stacks on top of the OS font scale. */
    val fontScale: Float = 1.0f,
    val family: FontFamilyToken = FontFamilyToken.DEFAULT,
)

@Serializable
data class ShapeSpec(
    /** Album-art corner radius in dp. 0 = square, large = circle-ish. */
    val albumArtCorner: Float = 12f,
    /** Panel/card corner radius in dp. */
    val panelCorner: Float = 16f,
)

@Serializable
data class MotionSpec(
    val animationScale: Float = 1.0f,
    val crossfadeMs: Int = 250,
)

@Serializable
enum class GradientStyle { NONE, LINEAR, RADIAL_BLOOM, MESH }

@Serializable
data class EffectSpec(
    val blurDp: Float = 12f,
    val gradientStyle: GradientStyle = GradientStyle.RADIAL_BLOOM,
    val gradientAnimated: Boolean = true,
    /** Music-reactive redraw rate. 0 disables. Degraded by the perf tier. */
    val reactiveFps: Int = 30,
) {
    /** Pure degradation — never produces a heavier spec than the input. */
    fun degradeTo(tier: com.nexus.audio.core.theming.resolve.PerfTier): EffectSpec = when (tier) {
        com.nexus.audio.core.theming.resolve.PerfTier.HIGH -> this
        com.nexus.audio.core.theming.resolve.PerfTier.BALANCED ->
            copy(blurDp = blurDp.coerceAtMost(16f), reactiveFps = reactiveFps.coerceAtMost(30))
        com.nexus.audio.core.theming.resolve.PerfTier.BATTERY ->
            copy(blurDp = 0f, gradientAnimated = false, reactiveFps = 0)
    }
}

@Serializable enum class NavItem { HOME, LIBRARY, SEARCH, DJ, SOCIAL, SETTINGS }
@Serializable enum class LibraryTab { SONGS, ALBUMS, ARTISTS, PLAYLISTS, DOWNLOADS, GENRES }
@Serializable enum class NowPlayingStyle { CLASSIC, FULL_ART, MINIMAL, DJ_DECK }

@Serializable
data class LayoutSpec(
    val navItems: List<NavItem> = listOf(NavItem.HOME, NavItem.LIBRARY, NavItem.SEARCH, NavItem.DJ),
    val libraryTabs: List<LibraryTab> = listOf(
        LibraryTab.SONGS, LibraryTab.ALBUMS, LibraryTab.ARTISTS, LibraryTab.PLAYLISTS,
    ),
    val nowPlaying: NowPlayingStyle = NowPlayingStyle.FULL_ART,
    val compact: Boolean = false,
    val largeArtwork: Boolean = true,
)
