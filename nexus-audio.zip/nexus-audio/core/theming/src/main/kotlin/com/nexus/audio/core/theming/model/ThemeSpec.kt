package com.nexus.audio.core.theming.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/** Bump when the on-disk shape changes; older specs are migrated on import. */
const val CURRENT_SCHEMA: Int = 1

@Serializable
enum class Mode { LIGHT, DARK, OLED }

/**
 * Where the palette comes from. Manual, Material You (wallpaper) and per-track
 * album-art extraction are NOT three render paths — they are three sources that
 * all feed the same token resolver. Add a new source here without touching any screen.
 */
@Serializable
sealed interface ColorSource {
    @Serializable @SerialName("manual")
    data class Manual(val argb: Long) : ColorSource

    @Serializable @SerialName("material_you")
    data object MaterialYou : ColorSource

    @Serializable @SerialName("album_art")
    data class AlbumArt(val fallbackArgb: Long) : ColorSource
}

/**
 * The entire appearance of the app as one serializable object.
 * Rendering, persistence, export/import, sharing and live preview are all just
 * this object in different contexts — there is no separate "preview engine".
 */
@Serializable
data class ThemeSpec(
    val schemaVersion: Int = CURRENT_SCHEMA,
    val id: String,
    val name: String,
    val author: String? = null,
    val mode: Mode = Mode.DARK,
    val colorSource: ColorSource,
    val surfaces: SurfaceSpec = SurfaceSpec(),
    val typography: TypographySpec = TypographySpec(),
    val shape: ShapeSpec = ShapeSpec(),
    val motion: MotionSpec = MotionSpec(),
    val effects: EffectSpec = EffectSpec(),
    val layout: LayoutSpec = LayoutSpec(),
)
