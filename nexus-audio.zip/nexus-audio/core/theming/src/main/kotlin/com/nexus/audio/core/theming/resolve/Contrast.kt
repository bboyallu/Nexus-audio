package com.nexus.audio.core.theming.resolve

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import kotlin.math.pow

/**
 * WCAG 2.1 relative-luminance contrast. The [ensure] function is what makes
 * "let users customize anything" safe: arbitrary accent colors on arbitrary
 * backgrounds get nudged toward black/white until text stays readable.
 */
object Contrast {

    private fun lin(c: Float): Double =
        if (c <= 0.03928f) c / 12.92 else ((c + 0.055) / 1.055).toDouble().pow(2.4)

    fun luminance(c: Color): Double =
        0.2126 * lin(c.red) + 0.7152 * lin(c.green) + 0.0722 * lin(c.blue)

    fun ratio(a: Color, b: Color): Double {
        val la = luminance(a) + 0.05
        val lb = luminance(b) + 0.05
        return if (la > lb) la / lb else lb / la
    }

    /**
     * Blend [fg] toward whichever extreme restores contrast against [bg].
     * target 4.5 = WCAG AA body text, 3.0 = AA large text.
     */
    fun ensure(fg: Color, bg: Color, target: Double = 4.5): Color {
        if (ratio(fg, bg) >= target) return fg
        val anchor = if (luminance(bg) < 0.5) Color.White else Color.Black
        var lo = 0f
        var hi = 1f
        var best = anchor
        repeat(12) {
            val t = (lo + hi) / 2f
            val candidate = lerp(fg, anchor, t)
            if (ratio(candidate, bg) >= target) {
                best = candidate
                hi = t
            } else {
                lo = t
            }
        }
        return best
    }
}
