package com.nexus.audio.core.theming.resolve

import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.isSpecified
import androidx.compose.ui.unit.sp
import com.nexus.audio.core.theming.model.EffectSpec
import com.nexus.audio.core.theming.model.FontFamilyToken
import com.nexus.audio.core.theming.model.ShapeSpec
import com.nexus.audio.core.theming.model.SurfaceSpec
import com.nexus.audio.core.theming.model.TypographySpec

internal fun FontFamilyToken.toFontFamily(): FontFamily? = when (this) {
    FontFamilyToken.DEFAULT -> null            // keep system default
    FontFamilyToken.ROUNDED -> FontFamily.SansSerif
    FontFamilyToken.MONO -> FontFamily.Monospace
    FontFamilyToken.SERIF -> FontFamily.Serif
}

internal fun TypographySpec.toTypography(systemFontScale: Float): Typography {
    val scale = (fontScale * systemFontScale).coerceIn(0.7f, 2.0f)
    val family = family.toFontFamily()

    fun TextStyle.tweak(): TextStyle = copy(
        fontFamily = family ?: fontFamily,
        fontSize = if (fontSize.isSpecified) (fontSize.value * scale).sp else fontSize,
        lineHeight = if (lineHeight.isSpecified) (lineHeight.value * scale).sp else lineHeight,
    )

    val b = Typography()
    return b.copy(
        displayLarge = b.displayLarge.tweak(), displayMedium = b.displayMedium.tweak(),
        displaySmall = b.displaySmall.tweak(),
        headlineLarge = b.headlineLarge.tweak(), headlineMedium = b.headlineMedium.tweak(),
        headlineSmall = b.headlineSmall.tweak(),
        titleLarge = b.titleLarge.tweak(), titleMedium = b.titleMedium.tweak(),
        titleSmall = b.titleSmall.tweak(),
        bodyLarge = b.bodyLarge.tweak(), bodyMedium = b.bodyMedium.tweak(),
        bodySmall = b.bodySmall.tweak(),
        labelLarge = b.labelLarge.tweak(), labelMedium = b.labelMedium.tweak(),
        labelSmall = b.labelSmall.tweak(),
    )
}

internal fun ShapeSpec.toShapes(): Shapes {
    val panel = panelCorner.coerceIn(0f, 40f)
    return Shapes(
        extraSmall = RoundedCornerShape((panel * 0.35f).dp),
        small = RoundedCornerShape((panel * 0.6f).dp),
        medium = RoundedCornerShape(panel.dp),
        large = RoundedCornerShape((panel * 1.4f).dp),
        extraLarge = RoundedCornerShape((panel * 1.9f).dp),
    )
}

internal fun EffectSpec.resolveWith(surfaces: SurfaceSpec): ResolvedEffects = ResolvedEffects(
    blurDp = blurDp.coerceIn(0f, 40f).dp,
    gradientStyle = gradientStyle,
    gradientAnimated = gradientAnimated,
    reactiveFps = reactiveFps.coerceIn(0, 60),
    glow = surfaces.glowArgb?.let { Color(it.toInt()) } ?: Color.Transparent,
    glowAlpha = surfaces.glowAlpha.coerceIn(0f, 1f),
    backgroundImageUri = surfaces.backgroundImageUri,
    backgroundImageDim = surfaces.backgroundImageDim.coerceIn(0f, 1f),
)
