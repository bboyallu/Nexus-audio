package com.nexus.audio.core.theming.resolve

/**
 * Effects are degraded against the active tier so music-reactive blur/gradients
 * never blow the frame budget. Drop to BATTERY automatically when the OS reports
 * power-save mode or low battery (see ResolveContext callers).
 */
enum class PerfTier { HIGH, BALANCED, BATTERY }
