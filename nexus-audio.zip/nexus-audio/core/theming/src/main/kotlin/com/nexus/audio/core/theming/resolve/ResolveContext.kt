package com.nexus.audio.core.theming.resolve

/**
 * Runtime inputs that the [ThemeSpec] doesn't carry: the live wallpaper seed
 * (Material You), the current track's extracted album-art seed, the device
 * performance tier, and the OS font scale.
 */
data class ResolveContext(
    val wallpaperSeed: Long? = null,
    val albumArtSeed: Long? = null,
    val perfTier: PerfTier = PerfTier.HIGH,
    val systemFontScale: Float = 1.0f,
)
