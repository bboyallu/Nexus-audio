package com.nexus.audio.core.theming.resolve

import androidx.compose.material3.ColorScheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.nexus.audio.core.theming.model.GradientStyle
import com.nexus.audio.core.theming.model.ThemeSpec

/** Effects already clamped to the perf tier and merged with surface glow. */
data class ResolvedEffects(
    val blurDp: Dp,
    val gradientStyle: GradientStyle,
    val gradientAnimated: Boolean,
    val reactiveFps: Int,
    val glow: Color,
    val glowAlpha: Float,
    val backgroundImageUri: String?,
    val backgroundImageDim: Float,
)

/** Everything a screen needs to render. Read from [com.nexus.audio.core.theming.runtime.LocalNexusTheme]. */
data class ResolvedTheme(
    val colors: ColorScheme,
    val typography: Typography,
    val shapes: Shapes,
    val effects: ResolvedEffects,
    val spec: ThemeSpec,
) {
    /** Convenience: album-art corner is consumed directly by image components. */
    val albumArtCorner: Dp get() = spec.shape.albumArtCorner.dp
}
