package com.nexus.audio.core.theming.resolve

import androidx.compose.material3.ColorScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.core.graphics.ColorUtils
import com.nexus.audio.core.theming.model.Mode

/**
 * Derives a full Material3 [ColorScheme] from a single seed color using HSL tones.
 *
 * This is a dependency-free approximation. For production-grade tonal harmony,
 * swap the body of [build] for material-color-utilities / MaterialKolor's
 * `dynamicColorScheme(seed)` — this is the ONLY function that needs to change.
 */
internal object SchemeBuilder {

    private fun hsl(c: Color): FloatArray =
        FloatArray(3).also { ColorUtils.colorToHSL(c.toArgb(), it) }

    private fun tone(base: FloatArray, l: Float, s: Float = base[1]): Color =
        Color(ColorUtils.HSLToColor(floatArrayOf(base[0], s.coerceIn(0f, 1f), l.coerceIn(0f, 1f))))

    private fun FloatArray.rotated(deg: Float): FloatArray =
        floatArrayOf((this[0] + deg) % 360f, this[1], this[2])

    fun build(seed: Color, mode: Mode): ColorScheme {
        val h = hsl(seed)
        val dark = mode != Mode.LIGHT
        val neutralSat = if (mode == Mode.OLED) 0f else 0.05f

        val bgL = when (mode) { Mode.OLED -> 0.0f; Mode.DARK -> 0.07f; Mode.LIGHT -> 0.98f }
        val surfL = when (mode) { Mode.OLED -> 0.04f; Mode.DARK -> 0.10f; Mode.LIGHT -> 0.96f }
        val onL = if (dark) 0.92f else 0.12f

        val primary = tone(h, if (dark) 0.72f else 0.42f)
        val onPrimary = tone(h, if (dark) 0.10f else 0.99f, s = 0.15f)
        val container = tone(h, if (dark) 0.26f else 0.86f)
        val onContainer = tone(h, if (dark) 0.90f else 0.18f)
        val secondary = tone(h.rotated(35f), if (dark) 0.66f else 0.46f, s = h[1] * 0.7f)
        val tertiary = tone(h.rotated(200f), if (dark) 0.70f else 0.46f, s = h[1] * 0.8f)
        val background = tone(h, bgL, neutralSat)
        val surface = tone(h, surfL, neutralSat)
        val onColor = tone(h, onL, 0.04f)

        return if (dark) {
            darkColorScheme(
                primary = primary, onPrimary = onPrimary,
                primaryContainer = container, onPrimaryContainer = onContainer,
                secondary = secondary, tertiary = tertiary,
                background = background, onBackground = onColor,
                surface = surface, onSurface = onColor,
                surfaceVariant = tone(h, (surfL + 0.06f), neutralSat),
                outline = tone(h, 0.45f, 0.03f),
            )
        } else {
            lightColorScheme(
                primary = primary, onPrimary = onPrimary,
                primaryContainer = container, onPrimaryContainer = onContainer,
                secondary = secondary, tertiary = tertiary,
                background = background, onBackground = onColor,
                surface = surface, onSurface = onColor,
                surfaceVariant = tone(h, (surfL - 0.06f), neutralSat),
                outline = tone(h, 0.60f, 0.03f),
            )
        }
    }
}
