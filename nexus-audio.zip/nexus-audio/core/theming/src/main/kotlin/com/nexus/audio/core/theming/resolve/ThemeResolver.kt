package com.nexus.audio.core.theming.resolve

import androidx.compose.material3.ColorScheme
import androidx.compose.ui.graphics.Color
import com.nexus.audio.core.theming.model.ColorSource
import com.nexus.audio.core.theming.model.ThemeSpec

/**
 * Pure, deterministic, unit-testable. Given a spec and runtime context it
 * produces a fully-rendered theme with contrast already enforced and effects
 * already degraded to the device tier.
 */
object ThemeResolver {

    private const val DEFAULT_SEED = 0xFF00F3FF // Nexus cyan

    fun resolve(spec: ThemeSpec, ctx: ResolveContext): ResolvedTheme {
        val seed = when (val src = spec.colorSource) {
            is ColorSource.Manual -> Color(src.argb.toInt())
            ColorSource.MaterialYou -> Color((ctx.wallpaperSeed ?: DEFAULT_SEED).toInt())
            is ColorSource.AlbumArt -> Color((ctx.albumArtSeed ?: src.fallbackArgb).toInt())
        }

        val colors = SchemeBuilder.build(seed, spec.mode).enforceContrast()
        val effects = spec.effects.degradeTo(ctx.perfTier).resolveWith(spec.surfaces)
        val typography = spec.typography.toTypography(ctx.systemFontScale)
        val shapes = spec.shape.toShapes()

        return ResolvedTheme(colors, typography, shapes, effects, spec)
    }

    /** Guarantee readable on-colors regardless of what the user picked. */
    private fun ColorScheme.enforceContrast(): ColorScheme = copy(
        onBackground = Contrast.ensure(onBackground, background),
        onSurface = Contrast.ensure(onSurface, surface),
        onSurfaceVariant = Contrast.ensure(onSurfaceVariant, surfaceVariant, target = 3.0),
        onPrimary = Contrast.ensure(onPrimary, primary),
        onPrimaryContainer = Contrast.ensure(onPrimaryContainer, primaryContainer),
        onSecondary = Contrast.ensure(onSecondary, secondary),
        onTertiary = Contrast.ensure(onTertiary, tertiary),
    )
}
