package com.nexus.audio.core.theming.runtime

import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.platform.LocalConfiguration
import com.nexus.audio.core.theming.model.ThemeSpec
import com.nexus.audio.core.theming.resolve.PerfTier
import com.nexus.audio.core.theming.resolve.ResolveContext
import com.nexus.audio.core.theming.resolve.ResolvedTheme
import com.nexus.audio.core.theming.resolve.ThemeResolver

/** Read the active resolved theme anywhere: `LocalNexusTheme.current.effects.glow`. */
val LocalNexusTheme = staticCompositionLocalOf<ResolvedTheme> {
    error("LocalNexusTheme not provided — wrap content in NexusTheme { }")
}

/**
 * Wrap the app (or any subtree, for per-screen overrides / live preview) in this.
 *
 * Live preview is literally this composable fed a draft [spec]. Per-screen
 * customization is a nested NexusTheme with a merged spec. No special code paths.
 *
 * @param wallpaperSeed fill from `dynamicDarkColorScheme(context).primary.value` on API 31+
 *                      when the spec's ColorSource is MaterialYou.
 * @param albumArtSeed  fill from your palette extractor for the current track.
 */
@Composable
fun NexusTheme(
    spec: ThemeSpec,
    wallpaperSeed: Long? = null,
    albumArtSeed: Long? = null,
    perfTier: PerfTier = PerfTier.HIGH,
    content: @Composable () -> Unit,
) {
    val systemFontScale = LocalConfiguration.current.fontScale
    val ctx = remember(wallpaperSeed, albumArtSeed, perfTier, systemFontScale) {
        ResolveContext(wallpaperSeed, albumArtSeed, perfTier, systemFontScale)
    }
    val resolved = remember(spec, ctx) { ThemeResolver.resolve(spec, ctx) }

    CompositionLocalProvider(LocalNexusTheme provides resolved) {
        MaterialTheme(
            colorScheme = resolved.colors,
            typography = resolved.typography,
            shapes = resolved.shapes,
            content = content,
        )
    }
}
