package com.nexus.audio.core.theming

import androidx.compose.ui.graphics.Color
import com.nexus.audio.core.theming.resolve.Contrast
import org.junit.Assert.assertTrue
import org.junit.Test

class ContrastTest {

    @Test fun black_on_white_is_max() {
        assertTrue(Contrast.ratio(Color.Black, Color.White) > 20.0)
    }

    @Test fun ensure_fixes_low_contrast() {
        // dim grey on near-black is unreadable; ensure() must lift it past AA
        val bg = Color(0xFF050505)
        val fixed = Contrast.ensure(Color(0xFF1A1A1A), bg, target = 4.5)
        assertTrue(Contrast.ratio(fixed, bg) >= 4.5)
    }
}
