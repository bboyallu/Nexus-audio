# Project Nexus Audio — Architecture & Customization Engine

A focused engineering blueprint. This is **not** an 18-section restatement of the spec — it goes deep on the load-bearing decisions and ships real starter code for the two subsystems everything else hangs off: the **provider/source abstraction** and the **theme/customization engine**.

---

## 0. Reality check (read this first)

The spec describes roughly 2–3 years of work for a small funded team. The failure mode is building all 18 deliverables horizontally (a thin layer of everything) and ending up with nothing that actually plays music well. The fix is a **thin vertical slice**: pick *local files + Navidrome* as the only two sources, get them into one unified library, one playback engine, one theme system — and ship that. Everything else is a plugin or a later phase against the *same* contracts.

Two hard truths the spec glosses over, worth confronting now because they shape the architecture:

1. **You cannot integrate Spotify / Apple Music / Tidal / Deezer the way the spec implies.** Their SDKs do not permit extracting and re-playing audio in your own ExoPlayer pipeline. Spotify's App Remote only *remote-controls the installed Spotify app*; Apple MusicKit only plays inside Apple's constraints for active subscribers; Tidal/Deezer are similar. So these are **control/metadata providers**, not **audio providers**. The architecture below models that distinction explicitly via capability flags instead of pretending all providers are equal. Real audio ownership comes from **local files + Jellyfin/Plex/Navidrome/Subsonic**, which is your genuine differentiator — lean into it.

2. **"Music-reactive visuals + 60 FPS + 500k tracks"** are three constraints in tension. They're achievable, but only if the visualizer reads from a fixed-size audio buffer off the main thread and the library never loads more than a page into memory. Designing for this on day one (below) is far cheaper than retrofitting it.

---

## 1. Module graph

Multi-module Gradle, by layer then feature. The two boxes that must stay clean are `core:media-source` (the provider contract) and `core:theming` — adding a provider or a theme must never touch app code.

```
nexus-audio/
├── app/                         # DI wiring, navigation host, Application
├── core/
│   ├── model/                   # pure Kotlin domain models (no Android deps)
│   ├── common/                  # Result, dispatchers, error types
│   ├── database/                # Room: entities, DAOs, migrations
│   ├── datastore/               # Proto DataStore: settings + AppearanceConfig
│   ├── network/                 # Ktor client factory, auth interceptors
│   ├── media-source/            # ★ MusicProvider contract + registry
│   ├── playback/                # Media3 session, queue, audio effects
│   └── theming/                 # ★ ThemeSpec, token resolver, contrast, CompositionLocals
├── source/                      # one module per provider — depends ONLY on core:media-source
│   ├── local/                   # MediaStore + SAF folders
│   ├── subsonic/                # covers Navidrome + Subsonic-compatible
│   ├── jellyfin/
│   ├── plex/
│   └── streaming-control/       # Spotify/Apple control-only providers
├── feature/
│   ├── home/  library/  search/  nowplaying/  djmode/
│   ├── ai-assistant/  social/  settings/  theme-editor/
└── auto/                        # Android Auto MediaLibraryService browse tree
```

Why feature modules: they enforce that `library` can't reach into `djmode`'s internals, they let Gradle parallelize and cache builds (critical at this size), and they keep the app module a thin assembler.

---

## 2. The unified domain model

One `Track` regardless of origin. The trick is a composite ID that namespaces by provider so a Navidrome track and a local file never collide, and so a row can be re-resolved later.

```kotlin
// core:model — pure Kotlin, zero Android imports
@JvmInline value class ProviderId(val value: String)   // "local", "navidrome:home", ...
@JvmInline value class TrackId(val value: String)       // provider-local id

data class GlobalId(val provider: ProviderId, val track: TrackId) {
    override fun toString() = "${provider.value}::${track.value}"
}

data class Track(
    val id: GlobalId,
    val title: String,
    val artist: String,
    val album: String,
    val genre: String?,
    val durationMs: Long,
    val artworkUri: String?,        // resolvable lazily; never block list scroll on it
    val fileType: String?,          // flac, mp3, opus...
    val quality: AudioQuality,      // bitDepth/sampleRate/bitrate or UNKNOWN
    val analysis: AudioAnalysis?,   // bpm/key — null until DJ analysis runs
    val lyricsState: LyricsState,   // NONE / UNSYNCED / SYNCED
    val download: DownloadState,    // NOT_DOWNLOADED / QUEUED / DOWNLOADED
    val isFavorite: Boolean,
    val playCount: Int,
    val lastPlayedAt: Long?,
)

data class AudioAnalysis(val bpm: Float, val key: CamelotKey, val energy: Float)
```

`analysis` being nullable is deliberate: BPM/key detection is expensive (DSP per track). You analyze **on demand** — when a track enters DJ Mode or a "sort harmonically" request — and cache the result in Room keyed by `GlobalId` + a content hash, never on every scan. For 500k tracks, eager analysis would be days of CPU.

---

## 3. Provider plugin system (deliverable #6)

This is the load-bearing wall. Every source — local, Navidrome, Spotify-control — implements one interface. Capabilities are declared, not assumed, which is exactly how you handle "Spotify can't actually stream into my player."

```kotlin
// core:media-source
enum class Capability { BROWSE, SEARCH, STREAM_AUDIO, DOWNLOAD, PLAYLISTS, LYRICS, SCROBBLE }

interface MusicProvider {
    val id: ProviderId
    val displayName: String
    val capabilities: Set<Capability>

    suspend fun authenticate(credentials: Credentials): Result<AuthState>
    suspend fun search(query: String, types: Set<MediaType>, page: PageRequest): Result<SearchPage>
    fun browse(node: BrowseNode): Flow<PagingData<MediaEntry>>

    /** Resolve how to actually play a track. Throws Unsupported if !STREAM_AUDIO. */
    suspend fun resolvePlayback(track: TrackId): Result<PlaybackSource>
}

sealed interface PlaybackSource {
    data class LocalFile(val uri: String) : PlaybackSource
    data class ProgressiveHttp(val url: String, val headers: Map<String, String>) : PlaybackSource
    data class Hls(val url: String, val headers: Map<String, String>) : PlaybackSource
    /** Control-only providers hand back a remote-control handle, not audio. */
    data class ExternalControl(val controller: RemoteController) : PlaybackSource
}
```

Registry with capability gating so feature code asks "who can search?" without knowing concrete types:

```kotlin
@Singleton
class ProviderRegistry @Inject constructor(providers: Set<@JvmSuppressWildcards MusicProvider>) {
    private val byId = providers.associateBy { it.id }
    fun get(id: ProviderId) = byId.getValue(id)
    fun withCapability(c: Capability) = byId.values.filter { c in it.capabilities }
}
```

Hilt multibinding makes each `source:*` module self-register:

```kotlin
@Module @InstallIn(SingletonComponent::class)
abstract class SubsonicProviderModule {
    @Binds @IntoSet abstract fun bind(impl: SubsonicProvider): MusicProvider
}
```

Adding Tidal later = a new `source:tidal` module with this binding. **Zero core changes** — which is the whole requirement.

> **Subsonic note:** implement Navidrome via the Subsonic API, not a Navidrome-specific client. That one module covers Navidrome, Airsonic, Gonic, and any Subsonic-compatible server — a large surface for a small amount of code.

---

## 4. Theme & customization engine (deliverables #10/#11 + the customization spec)

This is the part you've been circling, so it gets the most depth. The single architectural decision that unlocks **export, import, sharing, marketplace, cloud sync, and live preview all at once**:

> **The entire appearance is one serializable data object. The UI is a pure function of it.**

Nothing in the app reads "the theme" from scattered settings. There is one `ThemeSpec`; rendering, persistence, sharing, and preview are all just *that object* in different contexts. Live preview is "render the tree with a different `ThemeSpec` in a `CompositionLocal`" — free, no special code path.

### 4.1 The spec

```kotlin
// core:theming  — @Serializable so export/import/sync are trivial
@Serializable
data class ThemeSpec(
    val schemaVersion: Int = CURRENT_SCHEMA,
    val id: String,
    val name: String,
    val author: String? = null,
    val mode: Mode = Mode.DARK,            // LIGHT / DARK / OLED
    val colorSource: ColorSource,          // ← where colors COME from
    val surfaces: SurfaceSpec = SurfaceSpec(),
    val typography: TypographySpec = TypographySpec(),
    val shape: ShapeSpec = ShapeSpec(),    // albumArtCorner, panelCorner
    val motion: MotionSpec = MotionSpec(), // animationScale, crossfade
    val effects: EffectSpec = EffectSpec(),// blurDp, gradientStyle, reactiveLevel
    val layout: LayoutSpec = LayoutSpec(), // nav order, nowPlaying style, libraryTabs
)

@Serializable
sealed interface ColorSource {
    @Serializable data class Manual(val seed: Long) : ColorSource     // ARGB
    @Serializable data object MaterialYou : ColorSource              // wallpaper (Material You)
    @Serializable data class AlbumArt(val fallback: Long) : ColorSource // per-track dynamic
}
```

The `ColorSource` sealed type is the key abstraction: **manual themes, Material You, and album-art extraction are not three code paths — they're three sources that all produce the same token set.** Add a new source (e.g. "time of day") without touching any screen.

### 4.2 Resolution pipeline (pure, testable)

User inputs are small; UI needs a full token set. Resolution is a pure function — which means it's unit-testable and cacheable:

```kotlin
data class ResolvedTheme(
    val colors: ColorScheme,        // Material3 scheme
    val typography: Typography,
    val shapes: Shapes,
    val effects: ResolvedEffects,   // already clamped to the perf tier
    val spec: ThemeSpec,
)

fun resolve(spec: ThemeSpec, ctx: ResolveContext): ResolvedTheme {
    val seed = when (val s = spec.colorSource) {
        is ColorSource.Manual    -> Color(s.seed)
        is ColorSource.MaterialYou -> ctx.wallpaperSeed ?: Color(s = 0xFF00F3CB)
        is ColorSource.AlbumArt  -> ctx.albumArtSeed ?: Color(s.fallback)
    }
    val base = buildSchemeFromSeed(seed, spec.mode)   // tonal palette
    val safe = enforceContrast(base)                  // ← never ship unreadable text
    val effects = spec.effects.degradeTo(ctx.perfTier)// ← never drop frames
    return ResolvedTheme(safe, spec.typography.toM3(ctx.fontScale), spec.shape.toM3(),
                         effects, spec)
}
```

### 4.3 Accessibility contrast clamp (most apps skip this)

When users pick arbitrary accent colors and custom background images, text *will* become unreadable. Enforce WCAG contrast automatically by nudging on-colors — this is what makes "let users do anything" safe:

```kotlin
object Contrast {
    private fun lin(c: Float) =
        if (c <= 0.03928f) c / 12.92 else Math.pow((c + 0.055) / 1.055, 2.4)

    fun luminance(c: Color) = 0.2126 * lin(c.red) + 0.7152 * lin(c.green) + 0.0722 * lin(c.blue)

    fun ratio(a: Color, b: Color): Double {
        val la = luminance(a) + 0.05; val lb = luminance(b) + 0.05
        return if (la > lb) la / lb else lb / la
    }

    /** Blend [fg] toward black/white until it meets [target] (4.5 = WCAG AA body). */
    fun ensure(fg: Color, bg: Color, target: Double = 4.5): Color {
        if (ratio(fg, bg) >= target) return fg
        val anchor = if (luminance(bg) < 0.5) Color.White else Color.Black
        var lo = 0f; var hi = 1f; var best = anchor
        repeat(12) {
            val t = (lo + hi) / 2f
            val c = lerp(fg, anchor, t)
            if (ratio(c, bg) >= target) { best = c; hi = t } else lo = t
        }
        return best
    }
}
```

`enforceContrast` runs `ensure` over `onSurface/onPrimary/...` against their backgrounds. The theme editor shows a live pass/fail badge using `Contrast.ratio` so creators see violations before they save.

### 4.4 Apply it once, override per-screen

```kotlin
val LocalAppTheme = staticCompositionLocalOf<ResolvedTheme> { error("AppTheme not provided") }

@Composable
fun NexusTheme(spec: ThemeSpec, content: @Composable () -> Unit) {
    val ctx = rememberResolveContext()              // wallpaper, album seed, perf tier, font scale
    val resolved = remember(spec, ctx) { resolve(spec, ctx) }
    CompositionLocalProvider(LocalAppTheme provides resolved) {
        MaterialTheme(resolved.colors, resolved.typography, resolved.shapes, content)
    }
}
```

Per-screen customization (e.g. a different Now Playing palette) is just a nested `NexusTheme` with a merged spec. Live preview in the editor is the same component fed the draft spec — no separate preview engine.

### 4.5 Persistence, sharing, and untrusted input

- **Persistence:** the active `ThemeSpec` + saved themes live in **Proto DataStore**, observed as a `Flow<ThemeSpec>` at the root. Switching themes is a single emission; the whole tree recomposes against the new tokens.
- **Export/share:** `Json.encodeToString(spec)` → `.nexustheme` file or a short URL. Versioned via `schemaVersion` with a migration step on import.
- **Marketplace = untrusted input.** A downloaded theme is a stranger's data. Sanitize on import: clamp `fontScale`, `blurDp`, `animationScale` to safe ranges; re-run `enforceContrast`; validate any `customBackground` URI/size; reject unknown future `schemaVersion` rather than crash. Never trust a shared theme to be renderable as-is.

### 4.6 Performance tiering (the part that protects 60 FPS)

Music-reactive blur + animated gradients are GPU-heavy. Tier the effects and degrade automatically:

```kotlin
enum class PerfTier { HIGH, BALANCED, BATTERY }

fun EffectSpec.degradeTo(tier: PerfTier) = when (tier) {
    PerfTier.HIGH     -> this
    PerfTier.BALANCED -> copy(blurDp = blurDp.coerceAtMost(16f), reactiveFps = 30)
    PerfTier.BATTERY  -> copy(blurDp = 0f, gradientAnimated = false, reactiveFps = 0)
}
```

Rendering rules that matter more than the rules above:
- Visualizer reads a **fixed-size FFT buffer** populated off the audio thread; the composable only reads the latest snapshot. Never compute FFT in composition.
- Animated gradients/blur go through `Modifier.graphicsLayer` / `drawWithCache` so they don't invalidate the whole tree.
- Auto-drop to `BATTERY` when `PowerManager` reports low battery or `isPowerSaveMode`.

### 4.7 DJ Degon Mode (built-in)

Your aesthetic, encoded as a spec — near-black surfaces with a cyan glow:

```kotlin
val DJ_DEGON_MODE = ThemeSpec(
    id = "dj-degon", name = "DJ Degon Mode", mode = Mode.OLED,
    colorSource = ColorSource.Manual(seed = 0xFF00F3FF.toInt().toLong()), // cyan #00f3ff
    surfaces = SurfaceSpec(background = 0xFF050505, glow = 0xFF00F3FF, glowAlpha = 0.18f),
    effects = EffectSpec(blurDp = 20f, gradientStyle = Gradient.RADIAL_BLOOM, reactiveLevel = 3),
    shape = ShapeSpec(albumArtCorner = 4f, panelCorner = 18f),
)
```

---

## 5. Playback engine (deliverable #7), briefly

Media3 `MediaLibraryService` (not bare ExoPlayer) so Android Auto, Wear, and the notification get the browse tree for free. The provider returns a `PlaybackSource`; a small factory maps it to a `MediaSource`/`DataSource.Factory` (progressive, HLS, or a `ResolvingDataSource` that re-fetches expired stream URLs). Effects (EQ, ReplayGain, bass, loudness norm) attach via an `AudioProcessor` chain. Crossfade/gapless need two players ping-ponged or Media3's gapless support for same-source tracks.

---

## 6. Honest roadmap

| Phase | Scope | Why |
|---|---|---|
| **0 — Slice** | Local + Subsonic source, unified library in Room, Media3 playback, `ThemeSpec` engine with 3 built-ins | Proves every contract end-to-end. If this is good, you have a real app. |
| **1 — Core** | Search, downloads/offline (WorkManager), queue, EQ, theme editor + import/export | The daily-driver feature set. |
| **2 — Differentiate** | DJ Mode (on-demand BPM/key), Jellyfin/Plex, Android Auto, lyrics | Your moat: ownership + DJ tools. |
| **3 — Reach** | AI assistant (local LLM + cloud), social, marketplace, cloud sync, casting | Network-effect features — only after the core is loved. |

Defer aggressively: Spotify/Apple as *control-only* providers, server companion, desktop, Wear, yearly recap. They're real, but every one of them is a separate product.

---

## What I'd push back on in the spec

- **"Plugin for Spotify/Apple/Tidal/Deezer" implying unified audio** — not legally/technically possible; model them as control+metadata via `Capability`. Don't promise users something the platforms forbid.
- **Eager BPM/key on 500k tracks** — must be on-demand + cached, or first-scan takes days.
- **Encrypted offline cache + casting** — these fight: you can't cast DRM-encrypted local blobs to a dumb DLNA speaker. Decide per-source whether cache is encrypted-at-rest (tokens, paid streams) or plain (your own files).
- **"Most customizable UI available" without contrast enforcement** — that's how you ship unreadable themes. The clamp in §4.3 is non-negotiable, not a nice-to-have.
