pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "nexus-audio"

include(":core:theming")
include(":core:playback")
include(":source:youtube")
// As you add modules (see docs/architecture.md):
// include(":core:model", ":core:media-source", ":source:subsonic", ":feature:nowplaying", ...)
