# source:youtube

YouTube as a **search / metadata** provider for Nexus Audio. Implements the
`MusicProvider` contract so the registry picks it up automatically by capability.

## Read this before building on it

**YouTube does not give you playable audio.** The Data API `/search` returns
metadata only. There is no licensed way to stream YouTube audio inside ExoPlayer —
stream extraction violates the Terms of Service, breaks constantly (rotating
signatures), and gets API keys banned / apps removed from Play. So this provider
declares `capabilities = {SEARCH, BROWSE}` and `resolvePlayback` returns
`Unsupported` on purpose.

**Quota is the real constraint.** Each search call costs **100 units**; the default
project quota is **10,000 units/day** — roughly **100 searches per day for your
entire app**. Design accordingly:
- Cache aggressively (this module does; persist it to survive launches).
- Debounce input hard; never search per keystroke.
- Proxy through a backend so the quota and key live server-side, and you can batch /
  rate-limit centrally.

## The pattern that actually works

Use YouTube as a **discovery layer**, then play from something you own:

```
YouTube search → MediaEntry (title/artist/art) → fuzzy-match against
   local library / Subsonic → play THAT, or show "open in YouTube" via externalUrl
```

That gives users YouTube's catalog breadth for *finding* music while keeping
playback legal and offline-capable.

## What changed from the original snippet

| Original | Now |
|---|---|
| Bespoke class + `YouTubeTrack` | Implements `MusicProvider`, returns unified `MediaEntry` |
| `sourceUrl` implied playability | `externalUrl` only; `resolvePlayback` = Unsupported |
| No `@Serializable` | Annotated DTOs + `ignoreUnknownKeys` + safe defaults |
| Throws raw exceptions | `Result<>` with typed `ProviderError` (quota/auth/429/5xx) |
| No pagination | `nextPageToken` paging |
| No caching | TTL+LRU cache (mandatory for quota) |
| Raw HTML titles | Unescaped titles, cleaned `- Topic` channels |
| Key as constructor string, in query log | Lazy `suspend () -> String`; logging off by default |
| Assumed pre-configured client | Explicit Ktor factory: JSON, timeout, retry/backoff |

## Use it

```kotlin
val provider = YouTubeMusicProvider(
    http = youTubeHttpClient(),
    apiKey = { secureKeyStore.youtubeKey() }, // never a hardcoded string
)

when (val r = provider.search("progressive house", setOf(MediaType.TRACK), PageRequest(pageSize = 20))) {
    // r is Result<SearchPage>
    else -> r.fold(
        onSuccess = { page -> render(page.items); page.nextPageToken /* for "load more" */ },
        onFailure = { e -> when (e) {
            is ProviderError.QuotaExceeded -> showQuotaBanner()
            is ProviderError.Unauthorized  -> promptKeyFix()
            else -> showRetry()
        } },
    )
}
```

## Not verified to compile here

Authored outside a Gradle environment; Ktor/serialization versions are placeholders
to reconcile with your catalog. The pure utilities (`HtmlText`) have unit tests;
treat the first `./gradlew` as the integration step.
