package com.degonmusic.providers.youtube

/**
 * YouTube returns titles HTML-escaped ("Beats &amp; Pieces", "Don&#39;t Stop").
 * Display them raw and you ship visible `&amp;` everywhere. This is a small,
 * pure, dependency-free unescaper (no android.text.Html), so it unit-tests cleanly.
 */
internal object HtmlText {

    private val named = mapOf(
        "amp" to "&", "lt" to "<", "gt" to ">", "quot" to "\"",
        "apos" to "'", "nbsp" to " ", "#39" to "'", "#34" to "\"",
    )

    fun unescape(input: String): String {
        if ('&' !in input) return input
        val out = StringBuilder(input.length)
        var i = 0
        while (i < input.length) {
            val c = input[i]
            if (c == '&') {
                val end = input.indexOf(';', startIndex = i + 1)
                if (end in (i + 1)..(i + 10)) {
                    val entity = input.substring(i + 1, end)
                    val decoded = when {
                        entity.startsWith("#x") || entity.startsWith("#X") ->
                            entity.drop(2).toIntOrNull(16)?.let(::codePoint)
                        entity.startsWith("#") ->
                            entity.drop(1).toIntOrNull()?.let(::codePoint)
                        else -> named[entity]
                    }
                    if (decoded != null) { out.append(decoded); i = end + 1; continue }
                }
            }
            out.append(c)
            i++
        }
        return out.toString()
    }

    private fun codePoint(cp: Int): String? =
        runCatching { String(Character.toChars(cp)) }.getOrNull()

    /**
     * Music uploads use auto-generated "Artist - Topic" channels. Strip the suffix
     * so the artist reads cleanly. Leaves real channel names untouched.
     */
    fun cleanArtist(channelTitle: String): String =
        channelTitle.removeSuffix(" - Topic").trim().ifEmpty { channelTitle }
}
