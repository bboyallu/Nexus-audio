package com.degonmusic.providers.youtube

import com.degonmusic.providers.youtube.contract.SearchPage
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * The quota (≈100 searches/day for the whole app) makes caching non-optional.
 * Identical queries must never hit the network twice within the TTL.
 */
interface SearchCache {
    suspend fun get(key: String): SearchPage?
    suspend fun put(key: String, page: SearchPage)
}

/** Thread-safe TTL + LRU cache. Swap for a Room/DataStore-backed one to persist across launches. */
class InMemorySearchCache(
    private val maxEntries: Int = 200,
    private val ttlMillis: Long = 6 * 60 * 60 * 1000L, // 6h
    private val now: () -> Long = System::currentTimeMillis,
) : SearchCache {

    private data class Entry(val page: SearchPage, val expiresAt: Long)

    private val mutex = Mutex()
    private val map = object : LinkedHashMap<String, Entry>(16, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Entry>) =
            size > maxEntries
    }

    override suspend fun get(key: String): SearchPage? = mutex.withLock {
        val entry = map[key] ?: return null
        if (entry.expiresAt <= now()) { map.remove(key); null } else entry.page
    }

    override suspend fun put(key: String, page: SearchPage) = mutex.withLock {
        map[key] = Entry(page, now() + ttlMillis)
    }
}
