package com.degonmusic.providers.youtube

import io.ktor.client.HttpClient
import io.ktor.client.engine.HttpClientEngine
import io.ktor.client.engine.okhttp.OkHttp
import io.ktor.client.plugins.HttpRequestRetry
import io.ktor.client.plugins.HttpTimeout
import io.ktor.client.plugins.contentnegotiation.ContentNegotiation
import io.ktor.client.plugins.logging.LogLevel
import io.ktor.client.plugins.logging.Logging
import io.ktor.serialization.kotlinx.json.json
import kotlinx.serialization.json.Json

/**
 * One correctly-configured client for the provider. The original code assumed a
 * client that was already set up; this makes the requirements explicit:
 *
 *  - ContentNegotiation(json) with ignoreUnknownKeys — without it, `.body()` fails.
 *  - expectSuccess = false — so we inspect 4xx/5xx ourselves and map to ProviderError
 *    instead of having Ktor throw an opaque exception.
 *  - Timeouts + retry with exponential backoff on 5xx/429 (NOT on 403 quota — retrying
 *    a quota error just burns more goodwill).
 *  - Logging at HEADERS level only; never log the key-bearing query string.
 */
fun youTubeHttpClient(engine: HttpClientEngine? = null): HttpClient {
    val builder: io.ktor.client.HttpClientConfig<*>.() -> Unit = {
        expectSuccess = false

        install(ContentNegotiation) {
            json(Json { ignoreUnknownKeys = true; isLenient = true })
        }
        install(HttpTimeout) {
            requestTimeoutMillis = 20_000
            connectTimeoutMillis = 15_000
            socketTimeoutMillis = 20_000
        }
        install(HttpRequestRetry) {
            retryOnServerErrors(maxRetries = 3)
            retryOnException(maxRetries = 2, retryOnTimeout = true)
            // Do not retry 429/403 endlessly; back off and surface to the caller.
            exponentialDelay(base = 2.0, maxDelayMs = 8_000)
        }
        install(Logging) { level = LogLevel.NONE } // raise to HEADERS in debug only
    }
    return if (engine != null) HttpClient(engine, builder) else HttpClient(OkHttp, builder)
}
