package com.degonmusic.providers.youtube

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri

/** Outcome of a hand-off so callers can react instead of crashing on a tap. */
sealed interface LaunchResult {
    data object Launched : LaunchResult
    data object NoAppAvailable : LaunchResult
}

/**
 * Hands a track or search off to the YouTube / YouTube Music app, walking a
 * fallback chain down to the browser. Improvements over the original helper:
 *
 *  - Adds FLAG_ACTIVITY_NEW_TASK — required when launched from a non-Activity
 *    context, otherwise startActivity throws.
 *  - Every launch (including the web fallback) is guarded; a missing browser can
 *    no longer crash the app.
 *  - Returns a [LaunchResult] so the UI can show a snackbar on failure.
 *  - Tiered: YT Music app → YT app → browser, instead of a single try/catch.
 *  - Validates the video id; prefers the YT Music app for music links.
 *
 * NOTE (Android 11+): the targeted-package launches below only work if both
 * packages are declared in <queries> — see the manifest snippet in the README.
 * Without it, package visibility makes the apps invisible and every targeted
 * intent silently falls through to the browser.
 */
object YouTubeLauncher {

    private const val PKG_YT_MUSIC = "com.google.android.apps.youtube.music"
    private const val PKG_YT = "com.google.android.youtube"
    private val VIDEO_ID = Regex("^[A-Za-z0-9_-]{11}$")

    /** Open a track, preferring the YouTube app, then the browser. */
    fun openTrack(context: Context, videoId: String): LaunchResult {
        if (!VIDEO_ID.matches(videoId)) return LaunchResult.NoAppAvailable
        val watch = Uri.parse("https://www.youtube.com/watch?v=$videoId")
        return launchFirst(
            context,
            Intent(Intent.ACTION_VIEW, Uri.parse("vnd.youtube:$videoId")),
            Intent(Intent.ACTION_VIEW, watch),
        )
    }

    /** Open a track, preferring the YouTube Music app. */
    fun openTrackInYouTubeMusic(context: Context, videoId: String): LaunchResult {
        if (!VIDEO_ID.matches(videoId)) return LaunchResult.NoAppAvailable
        val musicWatch = Uri.parse("https://music.youtube.com/watch?v=$videoId")
        return launchFirst(
            context,
            Intent(Intent.ACTION_VIEW, musicWatch).setPackage(PKG_YT_MUSIC),
            Intent(Intent.ACTION_VIEW, Uri.parse("vnd.youtube:$videoId")).setPackage(PKG_YT),
            Intent(Intent.ACTION_VIEW, musicWatch),
        )
    }

    fun openSearchInYouTubeMusic(context: Context, query: String): LaunchResult {
        val q = query.trim()
        if (q.isEmpty()) return LaunchResult.NoAppAvailable
        val uri = Uri.parse("https://music.youtube.com/search?q=${Uri.encode(q)}")
        return launchFirst(
            context,
            Intent(Intent.ACTION_VIEW, uri).setPackage(PKG_YT_MUSIC),
            Intent(Intent.ACTION_VIEW, uri),
        )
    }

    /** Generic: open any external URL, e.g. a provider's MediaEntry.externalUrl. */
    fun openUrl(context: Context, url: String): LaunchResult =
        launchFirst(context, Intent(Intent.ACTION_VIEW, Uri.parse(url)))

    private fun launchFirst(context: Context, vararg intents: Intent): LaunchResult {
        for (intent in intents) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try {
                context.startActivity(intent)
                return LaunchResult.Launched
            } catch (_: ActivityNotFoundException) {
                // target app/handler not present — try the next fallback
            } catch (_: SecurityException) {
                // some OEM launchers block targeted packages — try the next fallback
            }
        }
        return LaunchResult.NoAppAvailable
    }
}
