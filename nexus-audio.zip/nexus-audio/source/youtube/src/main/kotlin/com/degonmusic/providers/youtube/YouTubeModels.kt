package com.degonmusic.providers.youtube

import kotlinx.serialization.Serializable

/**
 * DTOs mirror the YouTube Data API v3 JSON. `ignoreUnknownKeys = true` (set on the
 * Json instance) lets us ignore the dozens of fields we don't use. Defaults make
 * every field optional so a partial/changed payload never crashes deserialization.
 */

@Serializable
internal data class SearchListResponse(
    val items: List<SearchResult> = emptyList(),
    val nextPageToken: String? = null,
    val pageInfo: PageInfo? = null,
)

@Serializable
internal data class PageInfo(val totalResults: Int = 0, val resultsPerPage: Int = 0)

@Serializable
internal data class SearchResult(val id: ResourceId? = null, val snippet: Snippet? = null)

@Serializable
internal data class ResourceId(
    val kind: String? = null,
    val videoId: String? = null,
    val playlistId: String? = null,
    val channelId: String? = null,
)

@Serializable
internal data class Snippet(
    val title: String = "",
    val channelTitle: String = "",
    val thumbnails: Thumbnails? = null,
    val publishedAt: String? = null,
)

@Serializable
internal data class Thumbnails(
    val default: Thumbnail? = null,
    val medium: Thumbnail? = null,
    val high: Thumbnail? = null,
    val standard: Thumbnail? = null,
    val maxres: Thumbnail? = null,
) {
    /** Best available, largest first. */
    fun best(): String? =
        maxres?.url ?: standard?.url ?: high?.url ?: medium?.url ?: default?.url
}

@Serializable
internal data class Thumbnail(val url: String = "", val width: Int = 0, val height: Int = 0)

// --- error envelope -------------------------------------------------------

@Serializable
internal data class ErrorEnvelope(val error: ApiError? = null)

@Serializable
internal data class ApiError(
    val code: Int = 0,
    val message: String = "",
    val errors: List<ErrorDetail> = emptyList(),
)

@Serializable
internal data class ErrorDetail(val reason: String? = null, val domain: String? = null)
