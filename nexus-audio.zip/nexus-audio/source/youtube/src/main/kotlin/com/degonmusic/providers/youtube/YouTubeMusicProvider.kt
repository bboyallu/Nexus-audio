package com.degonmusic.providers.youtube

import com.degonmusic.providers.youtube.contract.Capability
import com.degonmusic.providers.youtube.contract.MediaEntry
import com.degonmusic.providers.youtube.contract.MediaType
import com.degonmusic.providers.youtube.contract.MusicProvider
import com.degonmusic.providers.youtube.contract.PageRequest
import com.degonmusic.providers.youtube.contract.PlaybackSource
import com.degonmusic.providers.youtube.contract.ProviderError
import com.degonmusic.providers.youtube.contract.ProviderId
import com.degonmusic.providers.youtube.contract.SearchPage
import io.ktor.client.HttpClient
import io.ktor.client.call.body
import io.ktor.client.request.get
import io.ktor.client.request.parameter
import io.ktor.client.statement.HttpResponse
import io.ktor.client.statement.bodyAsText
import kotlinx.serialization.json.Json

/**
 * YouTube as a SEARCH/BROWSE provider — deliberately NOT a streaming provider.
 * The Data API returns metadata only; there is no licensed way to pull the audio
 * into ExoPlayer, so [resolvePlayback] returns Unsupported and the app should match
 * results onto a streamable source (local/Subsonic) instead.
 *
 * Improvements over the original:
 *  - Implements the unified MusicProvider contract (was a bespoke class).
 *  - Result<> with typed ProviderError (quota vs auth vs network vs 5xx).
 *  - Pagination via nextPageToken (was none).
 *  - Search-result cache, required by the ~100-searches/day quota.
 *  - HTML-unescaped titles and cleaned "Artist - Topic" channels.
 *  - API key fetched lazily via a suspend provider (secure storage / remote config),
 *    never a constructor-baked string; key never logged.
 */
class YouTubeMusicProvider(
    private val http: HttpClient,
    private val apiKey: suspend () -> String,
    private val cache: SearchCache = InMemorySearchCache(),
) : MusicProvider {

    override val id = ProviderId("youtube")
    override val displayName = "YouTube"
    override val capabilities = setOf(Capability.SEARCH, Capability.BROWSE)

    private val json = Json { ignoreUnknownKeys = true }

    override suspend fun search(
        query: String,
        types: Set<MediaType>,
        page: PageRequest,
    ): Result<SearchPage> {
        val trimmed = query.trim()
        if (trimmed.isEmpty()) return Result.success(SearchPage(emptyList()))

        val key = cacheKey(trimmed, page)
        cache.get(key)?.let { return Result.success(it) }

        return runCatching {
            val response = fetch(trimmed, page)
            val parsed = mapResponse(response)
            cache.put(key, parsed)
            parsed
        }.recoverCatching { throwable ->
            // Normalise everything into a ProviderError so callers can switch on it.
            throw (throwable as? ProviderError) ?: ProviderError.Unexpected(throwable)
        }
    }

    /** YouTube has no licensed playback path; the contract default makes this explicit. */
    override suspend fun resolvePlayback(sourceId: String): Result<PlaybackSource> =
        Result.failure(ProviderError.Unsupported)

    // --- internals --------------------------------------------------------

    private suspend fun fetch(query: String, page: PageRequest): HttpResponse =
        try {
            http.get("$BASE_URL/search") {
                parameter("part", "snippet")
                parameter("q", query)
                parameter("type", "video")
                parameter("videoCategoryId", MUSIC_CATEGORY)
                parameter("maxResults", page.pageSize.coerceIn(1, 50))
                page.pageToken?.let { parameter("pageToken", it) }
                parameter("key", apiKey())
            }
        } catch (t: Throwable) {
            throw ProviderError.Network(t)
        }

    private suspend fun mapResponse(response: HttpResponse): SearchPage {
        when (val code = response.status.value) {
            in 200..299 -> {
                val body: SearchListResponse = response.body()
                val items = body.items.mapNotNull { it.toMediaEntry() }
                return SearchPage(items, body.nextPageToken)
            }
            401 -> throw ProviderError.Unauthorized
            403 -> throw if (isQuotaError(response)) ProviderError.QuotaExceeded
                         else ProviderError.Forbidden
            429 -> throw ProviderError.RateLimited(
                response.headers["Retry-After"]?.toLongOrNull(),
            )
            in 500..599 -> throw ProviderError.Server(code)
            else -> throw ProviderError.Unexpected(IllegalStateException("HTTP $code"))
        }
    }

    /** A 403 can be quota OR a disabled key OR referer block — only quota should pause searching. */
    private suspend fun isQuotaError(response: HttpResponse): Boolean = runCatching {
        val envelope = json.decodeFromString<ErrorEnvelope>(response.bodyAsText())
        envelope.error?.errors?.any { it.reason == "quotaExceeded" || it.reason == "dailyLimitExceeded" } == true
    }.getOrDefault(false)

    private fun SearchResult.toMediaEntry(): MediaEntry? {
        val videoId = id?.videoId ?: return null
        val snippet = snippet ?: return null
        return MediaEntry(
            providerId = this@YouTubeMusicProvider.id,
            sourceId = videoId,
            type = MediaType.TRACK,
            title = HtmlText.unescape(snippet.title),
            subtitle = HtmlText.cleanArtist(HtmlText.unescape(snippet.channelTitle)),
            artworkUrl = snippet.thumbnails?.best(),
            externalUrl = "https://www.youtube.com/watch?v=$videoId",
        )
    }

    private fun cacheKey(query: String, page: PageRequest): String =
        "yt:${query.lowercase()}:${page.pageSize}:${page.pageToken ?: "0"}"

    companion object {
        private const val BASE_URL = "https://www.googleapis.com/youtube/v3"
        private const val MUSIC_CATEGORY = "10"
    }
}
