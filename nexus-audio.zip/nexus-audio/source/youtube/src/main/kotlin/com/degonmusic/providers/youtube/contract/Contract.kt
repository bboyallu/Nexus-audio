package com.degonmusic.providers.youtube.contract

/**
 * A trimmed copy of the `core:media-source` contract, included so this module
 * compiles standalone. In the real project, delete this file and depend on
 * `core:media-source` instead — the types are identical by design.
 */

@JvmInline
value class ProviderId(val value: String)

enum class Capability { SEARCH, BROWSE, STREAM_AUDIO, DOWNLOAD, PLAYLISTS, LYRICS }

enum class MediaType { TRACK, ALBUM, ARTIST, PLAYLIST }

data class MediaEntry(
    val providerId: ProviderId,
    val sourceId: String,
    val type: MediaType,
    val title: String,
    val subtitle: String?,        // artist / channel
    val artworkUrl: String?,
    val externalUrl: String?,     // e.g. the YouTube watch URL, for "open in app"
    val durationMs: Long? = null,
)

data class PageRequest(val pageToken: String? = null, val pageSize: Int = 20)

data class SearchPage(val items: List<MediaEntry>, val nextPageToken: String? = null)

/** Where a streamable provider hands back its audio. YouTube never produces this. */
sealed interface PlaybackSource {
    data class LocalFile(val uri: String) : PlaybackSource
    data class ProgressiveHttp(val url: String, val headers: Map<String, String>) : PlaybackSource
    data class Hls(val url: String, val headers: Map<String, String>) : PlaybackSource
}

/** Typed, exhaustive failures so the UI can react (quota banners, re-auth, retry). */
sealed class ProviderError(message: String) : Exception(message) {
    data object Unauthorized : ProviderError("Invalid or missing API key")
    data object QuotaExceeded : ProviderError("YouTube Data API daily quota exceeded")
    data object Forbidden : ProviderError("Request forbidden")
    data class RateLimited(val retryAfterSeconds: Long?) : ProviderError("Rate limited")
    data class Server(val status: Int) : ProviderError("Server error $status")
    data class Network(val reason: Throwable?) : ProviderError("Network error: ${reason?.message}")
    data class Unexpected(val reason: Throwable?) : ProviderError("Unexpected: ${reason?.message}")
    data object Unsupported : ProviderError("Operation not supported by this provider")
}

interface MusicProvider {
    val id: ProviderId
    val displayName: String
    val capabilities: Set<Capability>

    suspend fun search(query: String, types: Set<MediaType>, page: PageRequest): Result<SearchPage>

    /** Streamable providers override this; non-audio providers return Unsupported. */
    suspend fun resolvePlayback(sourceId: String): Result<PlaybackSource> =
        Result.failure(ProviderError.Unsupported)
}
