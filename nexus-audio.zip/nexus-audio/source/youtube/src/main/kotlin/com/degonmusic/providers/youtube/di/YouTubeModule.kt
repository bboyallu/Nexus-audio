package com.degonmusic.providers.youtube.di

import com.degonmusic.providers.youtube.InMemorySearchCache
import com.degonmusic.providers.youtube.YouTubeMusicProvider
import com.degonmusic.providers.youtube.contract.MusicProvider
import com.degonmusic.providers.youtube.youTubeHttpClient
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import dagger.multibindings.IntoSet
import javax.inject.Singleton

/**
 * Registers YouTube into the app-wide Set<MusicProvider>. The registry then sees it
 * automatically via its SEARCH capability — no core code changes (the plugin goal).
 *
 * SECURITY: the key here is a placeholder. In production, fetch it from a backend
 * proxy or secure remote config, and restrict the key (Android app + API restriction)
 * in the Google Cloud console. An unrestricted Data API key shipped in an APK WILL be
 * extracted and abused against your quota.
 */
@Module
@InstallIn(SingletonComponent::class)
object YouTubeModule {

    @Provides
    @Singleton
    @IntoSet
    fun provideYouTubeProvider(): MusicProvider =
        YouTubeMusicProvider(
            http = youTubeHttpClient(),
            apiKey = { /* TODO: secure source */ "REPLACE_WITH_RESTRICTED_KEY" },
            cache = InMemorySearchCache(),
        )
}
