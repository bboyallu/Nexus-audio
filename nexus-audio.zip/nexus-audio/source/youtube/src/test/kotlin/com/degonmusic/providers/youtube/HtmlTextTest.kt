package com.degonmusic.providers.youtube

import org.junit.Assert.assertEquals
import org.junit.Test

class HtmlTextTest {

    @Test fun unescapes_named_and_numeric_entities() {
        assertEquals("Beats & Pieces", HtmlText.unescape("Beats &amp; Pieces"))
        assertEquals("Don't Stop", HtmlText.unescape("Don&#39;t Stop"))
        assertEquals("\"Quoted\"", HtmlText.unescape("&quot;Quoted&quot;"))
    }

    @Test fun leaves_plain_text_untouched() {
        val s = "Progressive House Mix 2026"
        assertEquals(s, HtmlText.unescape(s))
    }

    @Test fun strips_topic_suffix_from_channel() {
        assertEquals("DJ Degon", HtmlText.cleanArtist("DJ Degon - Topic"))
        assertEquals("Some Real Channel", HtmlText.cleanArtist("Some Real Channel"))
    }
}
