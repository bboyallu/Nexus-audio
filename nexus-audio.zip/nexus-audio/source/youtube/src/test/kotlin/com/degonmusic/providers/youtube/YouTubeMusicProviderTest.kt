package com.degonmusic.providers.youtube

import com.degonmusic.providers.youtube.contract.MediaType
import com.degonmusic.providers.youtube.contract.PageRequest
import com.degonmusic.providers.youtube.contract.ProviderError
import io.ktor.client.HttpClient
import io.ktor.client.engine.mock.MockEngine
import io.ktor.client.engine.mock.MockRequestHandleScope
import io.ktor.client.engine.mock.respond
import io.ktor.client.plugins.contentnegotiation.ContentNegotiation
import io.ktor.client.request.HttpRequestData
import io.ktor.client.request.HttpResponseData
import io.ktor.http.ContentType
import io.ktor.http.HttpHeaders
import io.ktor.http.HttpStatusCode
import io.ktor.http.headersOf
import io.ktor.serialization.kotlinx.json.json
import kotlinx.coroutines.test.runTest
import kotlinx.serialization.json.Json
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Exercises the provider against canned YouTube payloads via Ktor's MockEngine —
 * no network, no quota burned. Verifies mapping, filtering, pagination, caching,
 * and that every HTTP failure surfaces as the right typed ProviderError.
 */
class YouTubeMusicProviderTest {

    private val jsonHeaders = headersOf(HttpHeaders.ContentType, ContentType.Application.Json.toString())

    private fun newProvider(
        handler: suspend MockRequestHandleScope.(HttpRequestData) -> HttpResponseData,
    ): Pair<YouTubeMusicProvider, MockEngine> {
        val engine = MockEngine(handler)
        val client = HttpClient(engine) {
            expectSuccess = false
            install(ContentNegotiation) { json(Json { ignoreUnknownKeys = true }) }
        }
        return YouTubeMusicProvider(client, apiKey = { "TEST_KEY" }) to engine
    }

    private val TrackTypes = setOf(MediaType.TRACK)

    // --- success mapping --------------------------------------------------

    @Test fun maps_items_and_filters_non_videos() = runTest {
        val (provider, _) = newProvider { respond(SUCCESS_JSON, HttpStatusCode.OK, jsonHeaders) }

        val page = provider.search("progressive house", TrackTypes, PageRequest()).getOrThrow()

        assertEquals(1, page.items.size) // the channel result is dropped
        val entry = page.items.first()
        assertEquals("dQw4w9WgXcQ", entry.sourceId)
        assertEquals("Beats & Pieces (Don't Stop)", entry.title)      // HTML unescaped
        assertEquals("DJ Degon", entry.subtitle)                       // "- Topic" stripped
        assertEquals("https://i.ytimg.com/maxres.jpg", entry.artworkUrl) // best() picks maxres
        assertEquals("https://www.youtube.com/watch?v=dQw4w9WgXcQ", entry.externalUrl)
        assertEquals("CAUQAA", page.nextPageToken)
    }

    @Test fun sends_expected_query_parameters() = runTest {
        val (provider, engine) = newProvider { respond(SUCCESS_JSON, HttpStatusCode.OK, jsonHeaders) }

        provider.search("house", TrackTypes, PageRequest(pageToken = "TOKEN123", pageSize = 10)).getOrThrow()

        val params = engine.requestHistory.last().url.parameters
        assertEquals("snippet", params["part"])
        assertEquals("video", params["type"])
        assertEquals("10", params["videoCategoryId"])
        assertEquals("house", params["q"])
        assertEquals("TEST_KEY", params["key"])
        assertEquals("10", params["maxResults"])
        assertEquals("TOKEN123", params["pageToken"])
    }

    @Test fun blank_query_short_circuits_without_network() = runTest {
        val (provider, engine) = newProvider { respond(SUCCESS_JSON, HttpStatusCode.OK, jsonHeaders) }

        val page = provider.search("   ", TrackTypes, PageRequest()).getOrThrow()

        assertTrue(page.items.isEmpty())
        assertTrue(engine.requestHistory.isEmpty()) // no call made
    }

    // --- caching ----------------------------------------------------------

    @Test fun identical_query_is_served_from_cache() = runTest {
        val (provider, engine) = newProvider { respond(SUCCESS_JSON, HttpStatusCode.OK, jsonHeaders) }

        provider.search("same", TrackTypes, PageRequest()).getOrThrow()
        provider.search("same", TrackTypes, PageRequest()).getOrThrow()

        assertEquals(1, engine.requestHistory.size) // second call hit the cache
    }

    // --- typed error mapping ----------------------------------------------

    @Test fun quota_403_maps_to_QuotaExceeded() = runTest {
        val (provider, _) = newProvider { respond(QUOTA_JSON, HttpStatusCode.Forbidden, jsonHeaders) }

        val result = provider.search("x", TrackTypes, PageRequest())

        assertTrue(result.isFailure)
        assertEquals(ProviderError.QuotaExceeded, result.exceptionOrNull())
    }

    @Test fun non_quota_403_maps_to_Forbidden() = runTest {
        val (provider, _) = newProvider { respond(FORBIDDEN_JSON, HttpStatusCode.Forbidden, jsonHeaders) }

        val result = provider.search("x", TrackTypes, PageRequest())

        assertEquals(ProviderError.Forbidden, result.exceptionOrNull())
    }

    @Test fun unauthorized_401_maps_to_Unauthorized() = runTest {
        val (provider, _) = newProvider { respond("{}", HttpStatusCode.Unauthorized, jsonHeaders) }

        assertEquals(ProviderError.Unauthorized, provider.search("x", TrackTypes, PageRequest()).exceptionOrNull())
    }

    @Test fun rate_limited_429_carries_retry_after() = runTest {
        val headers = headersOf(HttpHeaders.RetryAfter, "30")
        val (provider, _) = newProvider { respond("{}", HttpStatusCode.TooManyRequests, headers) }

        val error = provider.search("x", TrackTypes, PageRequest()).exceptionOrNull()
        assertEquals(ProviderError.RateLimited(30L), error)
    }

    @Test fun server_5xx_maps_to_Server() = runTest {
        val (provider, _) = newProvider { respond("{}", HttpStatusCode.InternalServerError, jsonHeaders) }

        assertEquals(ProviderError.Server(500), provider.search("x", TrackTypes, PageRequest()).exceptionOrNull())
    }

    @Test fun transport_failure_maps_to_Network() = runTest {
        val (provider, _) = newProvider { throw java.io.IOException("boom") }

        val error = provider.search("x", TrackTypes, PageRequest()).exceptionOrNull()
        assertTrue(error is ProviderError.Network)
    }

    @Test fun resolvePlayback_is_unsupported() = runTest {
        val (provider, _) = newProvider { respond("{}", HttpStatusCode.OK, jsonHeaders) }

        assertEquals(ProviderError.Unsupported, provider.resolvePlayback("dQw4w9WgXcQ").exceptionOrNull())
    }

    private companion object {
        val SUCCESS_JSON = """
            {
              "nextPageToken": "CAUQAA",
              "items": [
                {
                  "id": { "kind": "youtube#video", "videoId": "dQw4w9WgXcQ" },
                  "snippet": {
                    "title": "Beats &amp; Pieces (Don&#39;t Stop)",
                    "channelTitle": "DJ Degon - Topic",
                    "thumbnails": {
                      "default": { "url": "https://i.ytimg.com/default.jpg" },
                      "medium":  { "url": "https://i.ytimg.com/medium.jpg" },
                      "high":    { "url": "https://i.ytimg.com/high.jpg" },
                      "maxres":  { "url": "https://i.ytimg.com/maxres.jpg" }
                    }
                  }
                },
                {
                  "id": { "kind": "youtube#channel", "channelId": "UC123" },
                  "snippet": { "title": "A Channel", "channelTitle": "A Channel" }
                }
              ]
            }
        """.trimIndent()

        val QUOTA_JSON = """
            {"error":{"code":403,"message":"quota","errors":[{"reason":"quotaExceeded","domain":"youtube.quota"}]}}
        """.trimIndent()

        val FORBIDDEN_JSON = """
            {"error":{"code":403,"message":"blocked","errors":[{"reason":"forbidden","domain":"global"}]}}
        """.trimIndent()
    }
}
